"""
Lang_World - The Omniverse Chronicles
An AI-Driven Dynamic RPG where the game world evolves in real-time

The Omniverse Chronicles is an infinitely evolving RPG where AETHERIUS,
an AI Game Master, dynamically generates and modifies the game world,
mechanics, and narrative based on player interactions.
"""

import pygame
import time
import json
from enum import Enum
from typing import Dict, List, Any, Optional
from pathlib import Path

# Import core systems
from core import AIGameMaster, ContextManager
from systems import (
    OmniverseGenerator, VoiceSystem, DynamicGameplay, AILearningSystem
)

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 900
TILE_SIZE = 64
FPS = 60

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
DEEP_PURPLE = (30, 20, 60)
CYAN = (0, 255, 255)
GOLD = (255, 215, 0)
DARK_GRAY = (40, 40, 40)
MED_GRAY = (80, 80, 80)
LIGHT_GRAY = (160, 160, 160)
VOID_BLUE = (20, 40, 80)
COSMIC_PURPLE = (80, 40, 120)
ENERGY_GREEN = (0, 255, 128)


class GameState(Enum):
    """Game state enumeration"""
    MAIN_MENU = 0
    CHARACTER_CREATION = 1
    PLAYING = 2
    DIALOGUE = 3
    COMBAT = 4
    INVENTORY = 5
    QUEST_MENU = 6
    PAUSED = 7


class Player:
    """Player character with stats and inventory"""
    
    def __init__(self, name: str):
        self.name = name
        self.health = 100
        self.max_health = 100
        self.mana = 50
        self.max_mana = 50
        self.attack = 10
        self.defense = 5
        self.level = 1
        self.experience = 0
        self.inventory = []
        self.abilities = []
        
        # Position
        self.x = 2
        self.y = 2
        self.region_x = 0
        self.region_y = 0
        self.depth = 0
        
        # Statistics
        self.kills = 0
        self.discoveries = 0
        self.deaths = 0
        self.quests_completed = 0
        
        # AI learning data
        self.recent_actions = []
    
    def move(self, dx: int, dy: int):
        """Move player"""
        self.x += dx
        self.y += dy
        
        # Handle region transitions
        if self.x < 0:
            self.region_x -= 1
            self.x = 4
        elif self.x > 4:
            self.region_x += 1
            self.x = 0
        if self.y < 0:
            self.region_y -= 1
            self.y = 4
        elif self.y > 4:
            self.region_y += 1
            self.y = 0
        
        # Record action
        self.recent_actions.append({
            'action_type': 'movement',
            'timestamp': time.time(),
            'location': (self.region_x, self.region_y, self.depth)
        })
    
    def add_experience(self, amount: int):
        """Add experience and handle level ups"""
        self.experience += amount
        if self.experience >= self.level * 100:
            self.level_up()
    
    def level_up(self):
        """Level up player"""
        self.level += 1
        self.max_health += 20
        self.health = self.max_health
        self.max_mana += 10
        self.mana = self.max_mana
        self.attack += 5
        self.defense += 2
        self.experience = 0
        print(f"🌟 Level up! Now level {self.level}")
    
    def take_damage(self, damage: int):
        """Take damage"""
        actual_damage = max(1, damage - self.defense)
        self.health -= actual_damage
        return actual_damage
    
    def heal(self, amount: int):
        """Heal player"""
        self.health = min(self.max_health, self.health + amount)
    
    def get_state(self) -> Dict[str, Any]:
        """Get player state for AI analysis"""
        return {
            'name': self.name,
            'level': self.level,
            'health': self.health,
            'max_health': self.max_health,
            'location': {
                'x': self.region_x,
                'y': self.region_y,
                'depth': self.depth
            },
            'statistics': {
                'kills': self.kills,
                'discoveries': self.discoveries,
                'deaths': self.deaths,
                'quests_completed': self.quests_completed
            }
        }


class LangWorld:
    """
    Main game class for Lang_World / The Omniverse Chronicles
    """
    
    def __init__(self):
        # Display
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Lang_World - The Omniverse Chronicles")
        self.clock = pygame.time.Clock()
        
        # Fonts
        self.title_font = pygame.font.Font(None, 72)
        self.large_font = pygame.font.Font(None, 48)
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        
        # Game state
        self.state = GameState.MAIN_MENU
        self.player = None
        self.current_region = None
        self.current_enemy = None
        
        # UI state
        self.dialogue_text = ""
        self.input_text = ""
        self.game_log = []
        self.scroll_offset = 0
        
        # Initialize AI systems
        print("\n" + "="*60)
        print("🌌 INITIALIZING LANG_WORLD - THE OMNIVERSE CHRONICLES")
        print("="*60)
        
        try:
            self.ai_game_master = AIGameMaster()
            self.omniverse = OmniverseGenerator(self.ai_game_master)
            self.voice_system = VoiceSystem()
            self.dynamic_gameplay = DynamicGameplay(self.ai_game_master)
            self.ai_learning = AILearningSystem()
            
            print("\n✅ All systems initialized successfully")
            print("="*60 + "\n")
            
        except Exception as e:
            print(f"\n❌ System initialization error: {str(e)}")
            print("="*60 + "\n")
            raise
        
        # Timing
        self.last_update_time = time.time()
        self.game_start_time = time.time()
        
    def add_game_log(self, message: str, speaker: str = "narrator"):
        """Add message to game log"""
        self.game_log.append(f"[{speaker}] {message}")
        if len(self.game_log) > 100:
            self.game_log = self.game_log[-100:]
    
    def handle_events(self) -> bool:
        """Handle pygame events"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            if self.state == GameState.MAIN_MENU:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        self.start_character_creation()
                    elif event.key == pygame.K_ESCAPE:
                        return False
            
            elif self.state == GameState.CHARACTER_CREATION:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and self.input_text.strip():
                        self.create_character(self.input_text.strip())
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_text = self.input_text[:-1]
                    elif event.key == pygame.K_ESCAPE:
                        self.state = GameState.MAIN_MENU
                    else:
                        if len(self.input_text) < 20:
                            self.input_text += event.unicode
            
            elif self.state == GameState.DIALOGUE:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and self.input_text.strip():
                        self.handle_dialogue_input()
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_text = self.input_text[:-1]
                    elif event.key == pygame.K_ESCAPE:
                        self.state = GameState.PLAYING
                    else:
                        if len(self.input_text) < 200:
                            self.input_text += event.unicode
            
            elif self.state == GameState.PLAYING:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_c:
                        self.enter_dialogue_mode()
                    elif event.key == pygame.K_i:
                        self.state = GameState.INVENTORY
                    elif event.key == pygame.K_q:
                        self.state = GameState.QUEST_MENU
                    elif event.key == pygame.K_ESCAPE or event.key == pygame.K_p:
                        self.state = GameState.PAUSED
                    elif event.key == pygame.K_TAB:
                        self.request_ai_generation()
            
            elif self.state == GameState.COMBAT:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        self.player_attack()
                    elif event.key == pygame.K_r:
                        self.flee_combat()
                    elif event.key == pygame.K_h:
                        self.use_heal()
            
            elif self.state in [GameState.INVENTORY, GameState.QUEST_MENU]:
                if event.type == pygame.KEYDOWN:
                    if event.key in [pygame.K_i, pygame.K_q, pygame.K_ESCAPE]:
                        self.state = GameState.PLAYING
            
            elif self.state == GameState.PAUSED:
                if event.type == pygame.KEYDOWN:
                    if event.key in [pygame.K_ESCAPE, pygame.K_p]:
                        self.state = GameState.PLAYING
                    elif event.key == pygame.K_m:
                        self.state = GameState.MAIN_MENU
        
        # Continuous movement in playing state
        if self.state == GameState.PLAYING:
            keys = pygame.key.get_pressed()
            dx, dy = 0, 0
            if keys[pygame.K_w] or keys[pygame.K_UP]:
                dy = -1
            if keys[pygame.K_s] or keys[pygame.K_DOWN]:
                dy = 1
            if keys[pygame.K_a] or keys[pygame.K_LEFT]:
                dx = -1
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
                dx = 1
            
            if dx != 0 or dy != 0:
                pygame.time.wait(150)  # Movement delay
                self.player.move(dx, dy)
                self.check_region_transition()
                self.check_encounters()
        
        return True
    
    def start_character_creation(self):
        """Start character creation"""
        self.state = GameState.CHARACTER_CREATION
        self.input_text = ""
        self.dialogue_text = "Welcome, Traveler of the Void. I am AETHERIUS, the Architect of Realities.\n\nYour journey begins at the edge of creation itself.\n\nWhat name shall echo through the cosmos?"
        
        self.voice_system.aetherius_speaks(
            "Welcome, Traveler of the Void. I am AETHERIUS, the Architect of Realities. "
            "Your journey begins at the edge of creation itself. What name shall echo through the cosmos?",
            "mysterious"
        )
    
    def create_character(self, player_name: str):
        """Create player character"""
        self.player = Player(player_name)
        self.ai_game_master.context_manager.update_player_name(player_name)
        
        # Generate origin story
        self.add_game_log(f"Creating character: {player_name}...", "system")
        
        origin_story = self.ai_game_master.generate_origin_story(player_name)
        self.ai_game_master.context_manager.update_player_origin(origin_story)
        
        # Generate starting region
        self.current_region = self.omniverse.generate_region(0, 0, 0, self.player.level)
        self.ai_game_master.context_manager.save_current_region(self.current_region)
        
        self.dialogue_text = origin_story
        self.voice_system.aetherius_speaks(origin_story, "epic")
        
        # Transition to playing
        pygame.time.wait(2000)
        self.state = GameState.PLAYING
        self.add_game_log(f"Welcome to the Omniverse, {player_name}!", "aetherius")
        self.add_game_log("Press C to chat with AETHERIUS, TAB to generate new content, I for inventory, Q for quests", "system")
    
    def enter_dialogue_mode(self):
        """Enter dialogue mode"""
        self.state = GameState.DIALOGUE
        self.input_text = ""
        self.dialogue_text = "Speak, and the cosmos shall listen..."
    
    def handle_dialogue_input(self):
        """Handle player dialogue input"""
        player_input = self.input_text.strip()
        self.input_text = ""
        
        self.add_game_log(f"You: {player_input}", "player")
        
        # Record action for learning
        self.player.recent_actions.append({
            'action_type': 'dialogue',
            'content': player_input,
            'timestamp': time.time()
        })
        self.ai_learning.record_action('dialogue', {'input': player_input}, self.player.get_state())
        
        # Get AI response
        response = self.ai_game_master.generate_dynamic_response(player_input, "dialogue")
        
        self.dialogue_text = response
        self.add_game_log(response, "aetherius")
        self.voice_system.aetherius_speaks(response, "mysterious")
        
        # Return to playing after brief delay
        pygame.time.wait(500)
        self.state = GameState.PLAYING
    
    def request_ai_generation(self):
        """Request AI to generate new content"""
        self.add_game_log("AETHERIUS weaves new reality...", "system")
        
        prompt = f"Generate interesting content for player at depth {self.player.depth}, region ({self.player.region_x}, {self.player.region_y})"
        response = self.ai_game_master.generate_dynamic_response(prompt, "generation")
        
        self.add_game_log("Reality shifts around you...", "narrator")
        self.voice_system.narrate("The fabric of reality shimmers and reconstitutes itself...", dramatic=True)
    
    def check_region_transition(self):
        """Check if player moved to new region"""
        region_key = f"{self.player.region_x}_{self.player.region_y}_{self.player.depth}"
        
        if not self.current_region or self.current_region.get('region_key') != region_key:
            # Generate new region
            self.current_region = self.omniverse.generate_region(
                self.player.region_x, self.player.region_y, self.player.depth, self.player.level
            )
            self.ai_game_master.context_manager.update_player_location(
                self.player.region_x, self.player.region_y, self.player.depth
            )
            self.ai_game_master.context_manager.save_current_region(self.current_region)
            
            self.player.discoveries += 1
            self.add_game_log(f"Discovered: {self.current_region['terrain']}", "narrator")
            
            if 'atmosphere_description' in self.current_region:
                self.voice_system.narrate(self.current_region['atmosphere_description'], dramatic=True)
    
    def check_encounters(self):
        """Check for entity encounters"""
        if not self.current_region:
            return
        
        for entity in self.current_region.get('entities', []):
            if entity['position']['x'] == self.player.x and entity['position']['y'] == self.player.y:
                if entity['behavior'] in ['aggressive', 'territorial']:
                    self.start_combat(entity)
                    break
    
    def start_combat(self, enemy: Dict[str, Any]):
        """Start combat"""
        self.current_enemy = enemy
        self.state = GameState.COMBAT
        self.add_game_log(f"Combat! {enemy['name']} appears!", "combat")
        self.voice_system.enemy_speaks(f"Prepare yourself, {self.player.name}!", "threatening")
    
    def player_attack(self):
        """Player attacks enemy"""
        if not self.current_enemy:
            return
        
        damage = max(1, self.player.attack - self.current_enemy.get('defense', 0))
        self.current_enemy['health'] -= damage
        
        self.add_game_log(f"You attack {self.current_enemy['name']} for {damage} damage!", "combat")
        
        if self.current_enemy['health'] <= 0:
            self.defeat_enemy()
        else:
            self.enemy_attack()
    
    def enemy_attack(self):
        """Enemy attacks player"""
        if not self.current_enemy:
            return
        
        damage = self.player.take_damage(self.current_enemy.get('attack', 5))
        self.add_game_log(f"{self.current_enemy['name']} attacks you for {damage} damage!", "combat")
        
        if self.player.health <= 0:
            self.player_death()
    
    def defeat_enemy(self):
        """Handle enemy defeat"""
        exp_gain = self.current_enemy.get('level', 1) * 20
        self.player.add_experience(exp_gain)
        self.player.kills += 1
        
        self.add_game_log(f"Defeated {self.current_enemy['name']}! Gained {exp_gain} EXP!", "combat")
        
        # Remove from region
        if self.current_region and 'entities' in self.current_region:
            self.current_region['entities'] = [
                e for e in self.current_region['entities'] if e != self.current_enemy
            ]
        
        self.current_enemy = None
        self.state = GameState.PLAYING
    
    def flee_combat(self):
        """Flee from combat"""
        self.add_game_log("You fled from combat!", "combat")
        self.current_enemy = None
        self.state = GameState.PLAYING
    
    def use_heal(self):
        """Use heal in combat"""
        if self.player.mana >= 10:
            self.player.mana -= 10
            heal_amount = 30
            self.player.heal(heal_amount)
            self.add_game_log(f"You heal for {heal_amount} HP!", "combat")
            self.enemy_attack()
        else:
            self.add_game_log("Not enough mana!", "combat")
    
    def player_death(self):
        """Handle player death"""
        self.player.deaths += 1
        self.player.health = self.player.max_health // 2
        self.player.x = 2
        self.player.y = 2
        self.add_game_log("You have been defeated... The void reclaims you, but you awaken anew.", "narrator")
        self.current_enemy = None
        self.state = GameState.PLAYING
    
    def update(self):
        """Update game state"""
        current_time = time.time()
        elapsed = current_time - self.last_update_time
        self.last_update_time = current_time
        
        if self.state == GameState.PLAYING and self.player:
            # Update dynamic gameplay
            self.dynamic_gameplay.update_game_world(self.player.get_state(), elapsed)
            
            # Update AI learning periodically
            if len(self.player.recent_actions) >= 10:
                self.ai_learning.update_player_model(self.player.recent_actions)
                self.player.recent_actions = []
    
    def render(self):
        """Render game"""
        self.screen.fill(DEEP_PURPLE)
        
        if self.state == GameState.MAIN_MENU:
            self.render_main_menu()
        elif self.state == GameState.CHARACTER_CREATION:
            self.render_character_creation()
        elif self.state == GameState.PLAYING:
            self.render_world()
        elif self.state == GameState.DIALOGUE:
            self.render_dialogue()
        elif self.state == GameState.COMBAT:
            self.render_combat()
        elif self.state == GameState.INVENTORY:
            self.render_inventory()
        elif self.state == GameState.QUEST_MENU:
            self.render_quests()
        elif self.state == GameState.PAUSED:
            self.render_paused()
        
        # Always render UI overlay
        if self.player and self.state not in [GameState.MAIN_MENU, GameState.CHARACTER_CREATION]:
            self.render_ui()
        
        pygame.display.flip()
    
    def render_main_menu(self):
        """Render main menu"""
        # Title
        title = self.title_font.render("LANG_WORLD", True, CYAN)
        subtitle = self.font.render("The Omniverse Chronicles", True, GOLD)
        
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 200))
        self.screen.blit(subtitle, (SCREEN_WIDTH // 2 - subtitle.get_width() // 2, 280))
        
        # Instructions
        start_text = self.large_font.render("Press ENTER to Begin", True, WHITE)
        quit_text = self.small_font.render("Press ESC to Quit", True, LIGHT_GRAY)
        
        self.screen.blit(start_text, (SCREEN_WIDTH // 2 - start_text.get_width() // 2, 450))
        self.screen.blit(quit_text, (SCREEN_WIDTH // 2 - quit_text.get_width() // 2, 550))
        
        # Footer
        footer = self.small_font.render("An AI-Driven Dynamic RPG", True, MED_GRAY)
        self.screen.blit(footer, (SCREEN_WIDTH // 2 - footer.get_width() // 2, SCREEN_HEIGHT - 50))
    
    def render_character_creation(self):
        """Render character creation screen"""
        # Draw dialogue
        self.draw_text_box(self.dialogue_text, 100, 150, SCREEN_WIDTH - 200, 200, self.small_font)
        
        # Input box
        input_box = pygame.Rect(100, 450, SCREEN_WIDTH - 200, 60)
        pygame.draw.rect(self.screen, MED_GRAY, input_box)
        pygame.draw.rect(self.screen, CYAN, input_box, 2)
        
        prompt = self.font.render("Your Name:", True, WHITE)
        self.screen.blit(prompt, (110, 415))
        
        input_text = self.font.render(self.input_text + "_", True, WHITE)
        self.screen.blit(input_text, (120, 465))
        
        hint = self.small_font.render("Press ENTER to continue, ESC to go back", True, LIGHT_GRAY)
        self.screen.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, 550))
    
    def render_world(self):
        """Render game world"""
        # Draw region grid
        grid_start_x = SCREEN_WIDTH // 2 - (2.5 * TILE_SIZE)
        grid_start_y = SCREEN_HEIGHT // 2 - (2.5 * TILE_SIZE)
        
        for x in range(5):
            for y in range(5):
                rect = pygame.Rect(
                    grid_start_x + x * TILE_SIZE,
                    grid_start_y + y * TILE_SIZE,
                    TILE_SIZE, TILE_SIZE
                )
                
                # Tile color based on terrain
                if self.current_region:
                    terrain = self.current_region.get('terrain', 'unknown')
                    if 'void' in terrain:
                        tile_color = VOID_BLUE
                    elif 'crystal' in terrain:
                        tile_color = COSMIC_PURPLE
                    else:
                        tile_color = DARK_GRAY
                else:
                    tile_color = DARK_GRAY
                
                pygame.draw.rect(self.screen, tile_color, rect)
                pygame.draw.rect(self.screen, MED_GRAY, rect, 1)
                
                # Draw player
                if x == self.player.x and y == self.player.y:
                    pygame.draw.circle(
                        self.screen,
                        CYAN,
                        (int(rect.centerx), int(rect.centery)),
                        TILE_SIZE // 3
                    )
                
                # Draw entities
                if self.current_region:
                    for entity in self.current_region.get('entities', []):
                        if entity['position']['x'] == x and entity['position']['y'] == y:
                            color = (255, 0, 0) if entity['behavior'] == 'aggressive' else (255, 255, 0)
                            pygame.draw.circle(
                                self.screen,
                                color,
                                (int(rect.centerx), int(rect.centery)),
                                TILE_SIZE // 4
                            )
        
        # Region info
        if self.current_region:
            terrain_text = self.font.render(f"{self.current_region['terrain']}", True, GOLD)
            self.screen.blit(terrain_text, (50, 50))
            
            coords_text = self.small_font.render(
                f"Region: ({self.player.region_x}, {self.player.region_y}) Depth: {self.player.depth}",
                True, LIGHT_GRAY
            )
            self.screen.blit(coords_text, (50, 90))
    
    def render_dialogue(self):
        """Render dialogue screen"""
        # Draw dialogue box
        self.draw_text_box(self.dialogue_text, 50, 100, SCREEN_WIDTH - 100, 300, self.small_font)
        
        # Input box
        input_box = pygame.Rect(50, 500, SCREEN_WIDTH - 100, 60)
        pygame.draw.rect(self.screen, MED_GRAY, input_box)
        pygame.draw.rect(self.screen, CYAN, input_box, 2)
        
        input_text = self.small_font.render(self.input_text + "_", True, WHITE)
        self.screen.blit(input_text, (70, 515))
        
        hint = self.small_font.render("Press ENTER to send, ESC to cancel", True, LIGHT_GRAY)
        self.screen.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, 580))
    
    def render_combat(self):
        """Render combat screen"""
        if not self.current_enemy:
            return
        
        # Enemy info
        enemy_name = self.large_font.render(self.current_enemy['name'], True, (255, 0, 0))
        self.screen.blit(enemy_name, (SCREEN_WIDTH // 2 - enemy_name.get_width() // 2, 100))
        
        enemy_health = self.font.render(
            f"HP: {self.current_enemy['health']} / {self.current_enemy.get('max_health', self.current_enemy['health'])}",
            True, WHITE
        )
        self.screen.blit(enemy_health, (SCREEN_WIDTH // 2 - enemy_health.get_width() // 2, 180))
        
        # Combat options
        options = [
            "SPACE - Attack",
            "H - Heal (10 mana)",
            "R - Flee"
        ]
        
        for i, option in enumerate(options):
            text = self.font.render(option, True, WHITE)
            self.screen.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, 350 + i * 50))
    
    def render_inventory(self):
        """Render inventory screen"""
        title = self.large_font.render("Inventory", True, GOLD)
        self.screen.blit(title, (50, 50))
        
        if not self.player.inventory:
            empty = self.font.render("Your inventory is empty", True, LIGHT_GRAY)
            self.screen.blit(empty, (50, 150))
        else:
            for i, item in enumerate(self.player.inventory):
                item_text = self.small_font.render(f"{item.get('name', 'Unknown')} ({item.get('type', '')})", True, WHITE)
                self.screen.blit(item_text, (50, 150 + i * 30))
        
        hint = self.small_font.render("Press I or ESC to close", True, LIGHT_GRAY)
        self.screen.blit(hint, (50, SCREEN_HEIGHT - 50))
    
    def render_quests(self):
        """Render quest menu"""
        title = self.large_font.render("Active Quests", True, GOLD)
        self.screen.blit(title, (50, 50))
        
        active_quests = self.dynamic_gameplay.get_active_quests()
        
        if not active_quests:
            empty = self.font.render("No active quests", True, LIGHT_GRAY)
            self.screen.blit(empty, (50, 150))
        else:
            for i, quest in enumerate(active_quests):
                quest_text = self.small_font.render(f"• {quest.title}", True, WHITE)
                self.screen.blit(quest_text, (50, 150 + i * 40))
                
                desc_text = self.small_font.render(f"  {quest.description[:60]}...", True, LIGHT_GRAY)
                self.screen.blit(desc_text, (60, 175 + i * 40))
        
        hint = self.small_font.render("Press Q or ESC to close", True, LIGHT_GRAY)
        self.screen.blit(hint, (50, SCREEN_HEIGHT - 50))
    
    def render_paused(self):
        """Render pause menu"""
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill(BLACK)
        self.screen.blit(overlay, (0, 0))
        
        title = self.title_font.render("PAUSED", True, CYAN)
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 200))
        
        options = [
            "P or ESC - Resume",
            "M - Return to Main Menu"
        ]
        
        for i, option in enumerate(options):
            text = self.font.render(option, True, WHITE)
            self.screen.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, 350 + i * 50))
    
    def render_ui(self):
        """Render UI overlay"""
        # Player stats panel
        stats_panel = pygame.Rect(10, 10, 300, 200)
        pygame.draw.rect(self.screen, DARK_GRAY, stats_panel)
        pygame.draw.rect(self.screen, CYAN, stats_panel, 2)
        
        stats = [
            f"{self.player.name} - Level {self.player.level}",
            f"HP: {self.player.health}/{self.player.max_health}",
            f"MP: {self.player.mana}/{self.player.max_mana}",
            f"ATK: {self.player.attack} | DEF: {self.player.defense}",
            f"EXP: {self.player.experience}/{self.player.level * 100}",
            f"Kills: {self.player.kills} | Discoveries: {self.player.discoveries}"
        ]
        
        for i, stat in enumerate(stats):
            text = self.small_font.render(stat, True, WHITE if i == 0 else LIGHT_GRAY)
            self.screen.blit(text, (20, 20 + i * 30))
        
        # Game log
        log_panel = pygame.Rect(10, SCREEN_HEIGHT - 210, 500, 200)
        pygame.draw.rect(self.screen, DARK_GRAY, log_panel)
        pygame.draw.rect(self.screen, CYAN, log_panel, 2)
        
        for i, message in enumerate(self.game_log[-7:]):
            text = self.small_font.render(message[:60], True, LIGHT_GRAY)
            self.screen.blit(text, (20, SCREEN_HEIGHT - 200 + i * 27))
        
        # Controls hint
        controls = self.small_font.render(
            "WASD: Move | C: Chat | TAB: Generate | I: Inventory | Q: Quests | P: Pause",
            True, MED_GRAY
        )
        self.screen.blit(controls, (SCREEN_WIDTH - controls.get_width() - 10, SCREEN_HEIGHT - 30))
    
    def draw_text_box(self, text: str, x: int, y: int, width: int, height: int, font):
        """Draw a text box with wrapped text"""
        box = pygame.Rect(x, y, width, height)
        pygame.draw.rect(self.screen, DARK_GRAY, box)
        pygame.draw.rect(self.screen, CYAN, box, 2)
        
        words = text.split(' ')
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            if font.size(test_line)[0] <= width - 40:
                current_line.append(word)
            else:
                if current_line:
                    lines.append(' '.join(current_line))
                current_line = [word]
        
        if current_line:
            lines.append(' '.join(current_line))
        
        for i, line in enumerate(lines):
            if i * 30 < height - 40:
                text_surf = font.render(line, True, WHITE)
                self.screen.blit(text_surf, (x + 20, y + 20 + i * 30))
    
    def run(self):
        """Main game loop"""
        running = True
        
        while running:
            running = self.handle_events()
            self.update()
            self.render()
            self.clock.tick(FPS)
        
        pygame.quit()
        print("\n🌌 Thank you for playing Lang_World - The Omniverse Chronicles")


if __name__ == "__main__":
    print("""
    ╔══════════════════════════════════════════════════════════╗
    ║                                                          ║
    ║              LANG_WORLD: THE OMNIVERSE CHRONICLES       ║
    ║                   An AI-Driven Dynamic RPG               ║
    ║                                                          ║
    ║  Where AETHERIUS, an AI Game Master, creates infinite   ║
    ║  worlds that evolve with your every choice              ║
    ║                                                          ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    
    game = LangWorld()
    game.run()
