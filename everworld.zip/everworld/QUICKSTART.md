# QUICKSTART - Lang_World

## ⚡ 5-Minute Setup

### 1. Prerequisites Check

```powershell
# Check Python version (need 3.9+)
python --version

# Check if Ollama is installed
ollama --version
```

### 2. Install Ollama (if needed)

Visit: https://ollama.ai/download

Or on Windows with PowerShell:
```powershell
# Download and install Ollama
# Then pull a model
ollama pull llama2
```

### 3. Install Game Dependencies

```powershell
cd "C:\Users\lokee\new stuff\FOAM\everworld"
pip install -r requirements.txt
```

### 4. Start Ollama Server

Open a **separate PowerShell terminal** and run:
```powershell
ollama serve
```

Leave this running in the background.

### 5. Launch the Game

```powershell
python lang_world.py
```

## 🎮 Your First 5 Minutes

### Main Menu
1. Press **ENTER** to start
2. Wait for AETHERIUS to greet you (with voice!)

### Character Creation
1. Type your character name
2. Press **ENTER**
3. Listen to your AI-generated origin story

### First Steps
1. Use **WASD** to move around the grid
2. Watch for **red circles** = enemies, **yellow** = neutrals
3. Press **C** to chat with AETHERIUS
4. Try asking: *"Create a challenging enemy for me"*

### First Combat
1. Walk into an enemy (red circle)
2. Press **SPACE** to attack
3. Press **H** to heal (costs 10 mana)
4. Press **R** to flee if needed

### Generate Content
1. Press **TAB** at any time
2. Watch AETHERIUS create new content
3. Explore new regions by moving off the grid edges

## 🎯 Essential Controls

| Key | Action |
|-----|--------|
| WASD | Move character |
| C | Chat with AETHERIUS |
| TAB | Generate new content |
| I | Open inventory |
| Q | View quests |
| P | Pause game |
| ESC | Exit menus |

## 💬 Example Conversations with AETHERIUS

Press **C** and try these:

```
"Tell me about this region"
"Create a mysterious NPC"
"I want a challenging quest"
"What's the lore of this world?"
"Make me a powerful weapon"
"Describe what I see around me"
```

## 🐛 Common Issues

### "Cannot connect to Ollama"
**Fix**: Make sure Ollama is running
```powershell
ollama serve
```

### "pyttsx3 import error"
**Fix**: Voice will work without it, or install:
```powershell
pip install pyttsx3
```

### Game is slow
**Fix 1**: Use a smaller model
```powershell
ollama pull llama2:7b
```

**Fix 2**: Disable voice in `config.json`
```json
"voice": {"enabled": false}
```

### AI responses are weird
**Fix**: Switch to a better model
```powershell
ollama pull mistral
```
Then edit `config.json`:
```json
"ollama": {"model": "mistral"}
```

## 📊 What to Expect

### Your First 10 Minutes
- Create character and hear origin story
- Explore 3-5 regions
- Encounter 2-3 enemies
- Level up once
- Chat with AETHERIUS

### After 30 Minutes
- Discover multiple biomes
- Complete 1-2 emergent quests
- Reach depth level 1-2
- AI learns your play style
- Difficulty adapts to you

### After 1 Hour
- Explored 15+ regions
- Level 3-5
- AI fully personalized to you
- Deep narrative threads
- Unique generated content

## 🎨 Customization

### Change AI Model
Edit `config.json`:
```json
"ollama": {
  "model": "mistral",      // or codellama, llama2, etc.
  "temperature": 0.9       // 0.0 = predictable, 1.0 = creative
}
```

### Adjust Difficulty
Edit `config.json`:
```json
"difficulty": {
  "starting_difficulty": 1.5,  // Higher = harder start
  "adaptive_difficulty": false  // Disable auto-adjustment
}
```

### Disable Voice
Edit `config.json`:
```json
"voice": {
  "enabled": false
}
```

## 🔥 Pro Tips

1. **Talk to AETHERIUS frequently** - It learns from conversations
2. **Press TAB often** - Generates fresh, interesting content
3. **Explore depth levels** - Find portals to go deeper (harder but better rewards)
4. **Let it learn** - The AI adapts over time, give it 30+ minutes
5. **Be specific** - "Create a fire-breathing dragon" works better than "make something"

## 🌟 Cool Things to Try

### Request Specific Content
```
"Generate a haunted forest region"
"Create a merchant NPC who sells rare items"
"Make a puzzle quest"
"Add a boss enemy"
```

### Roleplay
```
"I want to negotiate with this enemy"
"Tell me a legend about this place"
"What happens if I touch the glowing crystal?"
```

### Challenge Yourself
```
"Make the next region extremely difficult"
"Create a time-limited quest"
"Spawn three enemies at once"
```

## 📁 File Structure (Important)

```
everworld/
├── lang_world.py          ← Run this to start
├── config.json            ← Edit for settings
├── requirements.txt       ← Install dependencies from here
├── game_world/            ← Your game data (created on first run)
│   ├── universe/          ← Game state
│   └── regions/           ← Generated regions
├── core/                  ← AI systems
└── systems/               ← Game systems
```

## 🆘 Need Help?

### Check Logs
```powershell
# Game creates these directories on first run:
# game_world/safety/safety_log.json - Blocked content
# game_world/ai_memory/ - Learning data
```

### Test Ollama Separately
```powershell
# Test if Ollama is working:
ollama run llama2
# Type: hello
# Should get a response
```

### Reset Everything
```powershell
# Delete game data to start fresh:
Remove-Item -Recurse -Force game_world
Remove-Item game_state.db
```

## 🎊 You're Ready!

Launch the game and begin your journey through the infinite Omniverse!

```powershell
python lang_world.py
```

**Remember**: Press **C** to chat with AETHERIUS anytime, and press **TAB** to generate new content.

*"May your consciousness expand infinitely through the Omniverse."*  
— AETHERIUS
