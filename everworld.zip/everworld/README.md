# Lang_World: The Omniverse Chronicles

**An AI-Driven Dynamic RPG Where Reality Itself Evolves**

## 🌌 Overview

Lang_World (The Omniverse Chronicles) is a revolutionary RPG where **AETHERIUS**, an AI Game Master powered by Ollama, doesn't just respond to your actions—it actively generates, modifies, and evolves the entire game universe in real-time based on your play style, decisions, and interactions.

The game world is **infinite**, **procedurally generated**, and **continuously adapting**. Every region, quest, NPC, and mechanic can be dynamically created or modified by the AI, making each playthrough truly unique.

## ✨ Key Features

### 🤖 **AI Game Master - AETHERIUS**
- **Real-time world generation**: AI creates new regions, enemies, items, and quests dynamically
- **Contextual awareness**: Remembers your journey, decisions, and play style
- **Emotional intelligence**: Adapts narrative tone and difficulty based on your reactions
- **Voice narration**: Speaks all dialogue and narration with emotional tones (optional TTS)

### 🌍 **Infinite Procedural Universe**
- **Omniverse generation**: Explore infinite regions across multiple depth levels
- **Cosmic signatures**: Each region has unique properties and characteristics
- **Dimensional properties**: Reality stability, temporal flux, void proximity
- **Quantum connections**: Regions interconnect in mysterious ways

### 🎮 **Dynamic Gameplay Systems**
- **Emergent quests**: Quests generate based on your actions and location
- **Adaptive difficulty**: Game adjusts challenge based on your performance
- **Real-time events**: World events unfold dynamically
- **Player learning**: AI learns your preferences and adapts content

### 🎭 **Voice System**
- **Emotional TTS**: AETHERIUS speaks with different emotional tones
- **Character voices**: NPCs, enemies, and narrator have distinct voices
- **Dramatic narration**: Key moments are voice-acted
- **Async speech**: Voice runs in background, doesn't block gameplay

### 🔒 **Safety Systems**
- **Code validation**: AI-generated code is sandboxed and validated
- **Content filtering**: Inappropriate content is blocked
- **Performance limits**: Prevents system overload
- **Rollback capability**: Can revert problematic changes

## 🚀 Quick Start

### Prerequisites

1. **Python 3.9+**
2. **Ollama** running locally with a language model (llama2, mistral, etc.)
3. **Git** (to clone the repo)

### Installation

```powershell
# Navigate to the everworld directory
cd "C:\Users\lokee\new stuff\FOAM\everworld"

# Install Python dependencies
pip install -r requirements.txt

# Ensure Ollama is running
# Open a separate terminal and run:
ollama serve

# Pull a model if you haven't already
ollama pull llama2
```

### Running the Game

```powershell
python lang_world.py
```

### First Launch

1. **Main Menu**: Press ENTER to begin
2. **Character Creation**: AETHERIUS will ask your name
3. **Origin Story**: AI generates a unique origin story for you
4. **Explore**: Use WASD to move through the infinite Omniverse

## 🎮 Controls

### Main Controls
- **WASD / Arrow Keys**: Move through regions
- **C**: Chat with AETHERIUS (dialogue mode)
- **TAB**: Request AI to generate new content
- **I**: Open inventory
- **Q**: View quests
- **P / ESC**: Pause game

### Combat Controls
- **SPACE**: Attack enemy
- **H**: Heal (costs 10 mana)
- **R**: Flee from combat

### Dialogue Mode
- **Type**: Enter your message
- **ENTER**: Send message to AETHERIUS
- **ESC**: Cancel and return to game

## 🏗️ Architecture

### Core Systems

```
everworld/
├── core/                      # Core AI systems
│   ├── ai_game_master.py      # Main AI orchestrator
│   ├── context_manager.py     # Game state & context
│   ├── code_generator.py      # Safe code execution
│   └── safety_manager.py      # Safety validation
├── systems/                   # Game systems
│   ├── omniverse_generator.py # Procedural world gen
│   ├── voice_system.py        # TTS and narration
│   ├── dynamic_gameplay.py    # Events & quests
│   └── ai_learning.py         # Player profiling
├── game_world/                # Persistent data
│   ├── universe/              # Global game state
│   ├── regions/               # Generated regions
│   ├── ai_memory/             # AI learning data
│   ├── code_templates/        # Generated mechanics
│   └── safety/                # Safety logs
└── lang_world.py              # Main game entry
```

### AI Integration Flow

```
Player Action
    ↓
Context Manager (builds comprehensive prompt)
    ↓
AI Game Master (calls Ollama)
    ↓
Safety Manager (validates response)
    ↓
Code Generator (executes safely)
    ↓
World Updated / Voice Narration
    ↓
AI Learning System (records preferences)
```

## 🌌 Gameplay Loop

### 1. **Exploration**
- Move through procedurally generated regions
- Discover new biomes, entities, and features
- Each region has cosmic significance and unique properties

### 2. **Combat**
- Encounter enemies dynamically generated by AI
- Strategic turn-based combat with attack/defend/heal
- Enemies have AI-controlled behaviors and tactics

### 3. **Dialogue**
- Chat with AETHERIUS at any time
- AI responds contextually based on your journey
- Can request specific content, ask questions, or roleplay

### 4. **Progression**
- Level up through combat and exploration
- Discover items and abilities
- Complete emergent quests

### 5. **AI Adaptation**
- Game learns your play style (combat-focused, explorer, story-focused)
- Content adapts to your preferences
- Difficulty scales to your performance

## 🎯 Advanced Features

### AI Content Generation

Press **TAB** at any time to request AETHERIUS to generate:
- New enemies with unique abilities
- Special items and artifacts
- Hidden locations and secrets
- Narrative events and lore
- New game mechanics

### Emergent Quests

The AI generates quests based on:
- Your current location and depth
- Your play style and preferences
- Recent actions and discoveries
- World state and narrative threads

### Dynamic Difficulty

The game automatically adjusts:
- **Too Easy**: Enemies get stronger, events more challenging
- **Too Hard**: Enemies weaken, more resources appear
- **Balanced**: Maintains engagement sweet spot

### Voice Narration

AETHERIUS speaks with different emotional tones:
- **Mysterious**: Default wise and enigmatic
- **Epic**: Grand moments and revelations
- **Ominous**: Warnings and dark discoveries
- **Excited**: Victories and breakthroughs

## 🔧 Configuration

Edit `config.json` to customize:

```json
{
  "ollama": {
    "model": "llama2",        // Change AI model
    "temperature": 0.8         // Creativity (0.0-1.0)
  },
  "voice": {
    "enabled": true,           // Enable/disable TTS
    "rate": 150                // Speech speed
  },
  "gameplay": {
    "adaptive_difficulty": true,
    "emergent_quests": true
  }
}
```

## 🐛 Troubleshooting

### Ollama Connection Issues

```powershell
# Check if Ollama is running
curl http://localhost:11434/api/tags

# Restart Ollama
ollama serve
```

### Voice System Not Working

```powershell
# Install pyttsx3 dependencies
pip install pyttsx3 --upgrade

# On Windows, ensure SAPI5 voices are installed
# Voice will gracefully fallback to text-only if TTS fails
```

### Game Performance

- Reduce `region_cache_size` in config.json
- Disable voice with `"voice": {"enabled": false}`
- Use a smaller Ollama model (e.g., `ollama pull llama2:7b`)

### AI Generation Slow

- Use a faster model: `ollama pull mistral`
- Reduce `default_max_tokens` in config.json
- Upgrade hardware or use GPU acceleration

## 📊 Game Data

### Persistent Files

- `game_world/universe/` - Global game state
- `game_world/regions/` - Generated regions (cached)
- `game_world/ai_memory/` - Player preferences and learning
- `game_state.db` - Original game state database (legacy)

### AI Learning

The AI learns from:
- **Action patterns**: Combat frequency, exploration habits
- **Decision history**: Choices in dialogue and quests
- **Emotional responses**: Inferred from gameplay behavior
- **Content engagement**: What content you interact with most

## 🎨 Customization

### Modify AI Personality

Edit `core/ai_game_master.py`:

```python
self.personality = {
    'name': 'YOUR_AI_NAME',
    'tone': 'friendly/dark/cosmic/etc',
    'creativity': 0.9  # Higher = more creative
}
```

### Add Custom Biomes

Edit `systems/omniverse_generator.py` → `BiomeGenerator.biomes`

### Create Quest Templates

Add to `systems/dynamic_gameplay.py` → `EmergentQuestGenerator.quest_templates`

## 🌟 Tips for Best Experience

1. **Talk to AETHERIUS**: Use dialogue mode (C) to shape your experience
2. **Be specific**: Ask for specific types of content you want to see
3. **Explore freely**: The universe is infinite—there's always more to discover
4. **Let AI adapt**: Play naturally, and the game will learn your preferences
5. **Use TAB frequently**: Generate new content to keep things fresh

## 🔮 Future Enhancements

- **Multiplayer**: Co-op exploration with shared AI Game Master
- **Visual upgrades**: Sprite system, particle effects, enhanced UI
- **Save/Load system**: Persist game state across sessions
- **Web dashboard**: View AI stats, world map, and narrative threads
- **Advanced AI**: Multi-agent systems, memory networks, chain-of-thought
- **Mod support**: Plugin system for custom content and mechanics

## 📝 Credits

**Game Design & Development**: AI-Human Collaboration
**AI Game Master**: Powered by Ollama (llama2, mistral, etc.)
**Engine**: Python + Pygame
**TTS**: pyttsx3

## 📜 License

Open source - feel free to modify and extend!

## 🆘 Support

For issues, feature requests, or questions:
- Check `game_world/safety/safety_log.json` for blocked content
- Review `game_world/ai_memory/` for learning data
- Monitor terminal output for system messages

## 🌌 Philosophy

Lang_World represents a new paradigm in gaming where the game isn't just played—it's **co-created** in real-time between human and AI. AETHERIUS isn't just a character or a tool; it's a collaborative storyteller, dungeon master, and world architect that evolves the game universe in response to your unique journey.

**Every playthrough is a unique story. Every decision shapes reality. Every player creates their own Omniverse.**

---

*"Welcome, Traveler of the Void. Your journey begins at the edge of creation itself."*  
— AETHERIUS, The Omniversal Architect
