# Lang_World Launch Script
# Checks prerequisites and launches the game

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  LANG_WORLD: THE OMNIVERSE CHRONICLES" -ForegroundColor Cyan
Write-Host "  An AI-Driven Dynamic RPG" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Check Python
Write-Host "[1/5] Checking Python..." -ForegroundColor Yellow
try {
    $pythonVersion = python --version 2>&1
    Write-Host "  ✓ $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "  ✗ Python not found! Please install Python 3.9+" -ForegroundColor Red
    exit 1
}

# Check Ollama
Write-Host "[2/5] Checking Ollama..." -ForegroundColor Yellow
try {
    $ollamaVersion = ollama --version 2>&1
    Write-Host "  ✓ $ollamaVersion" -ForegroundColor Green
} catch {
    Write-Host "  ✗ Ollama not found! Please install from https://ollama.ai" -ForegroundColor Red
    exit 1
}

# Check Ollama connection
Write-Host "[3/5] Checking Ollama server..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -Method Get -TimeoutSec 5 -ErrorAction Stop
    Write-Host "  ✓ Ollama server is running" -ForegroundColor Green
} catch {
    Write-Host "  ⚠ Ollama server not responding" -ForegroundColor Yellow
    Write-Host "  Starting Ollama server..." -ForegroundColor Yellow
    Start-Process -FilePath "ollama" -ArgumentList "serve" -WindowStyle Hidden
    Start-Sleep -Seconds 3
    Write-Host "  ✓ Ollama server started" -ForegroundColor Green
}

# Check dependencies
Write-Host "[4/5] Checking Python dependencies..." -ForegroundColor Yellow
$required = @("pygame", "requests")
$missing = @()

foreach ($package in $required) {
    $check = python -c "import $package" 2>&1
    if ($LASTEXITCODE -ne 0) {
        $missing += $package
    }
}

if ($missing.Count -gt 0) {
    Write-Host "  ⚠ Missing packages: $($missing -join ', ')" -ForegroundColor Yellow
    Write-Host "  Installing dependencies..." -ForegroundColor Yellow
    pip install -r requirements.txt
    Write-Host "  ✓ Dependencies installed" -ForegroundColor Green
} else {
    Write-Host "  ✓ All dependencies installed" -ForegroundColor Green
}

# Launch game
Write-Host "[5/5] Launching Lang_World..." -ForegroundColor Yellow
Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  🌌 Starting The Omniverse Chronicles..." -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

python lang_world.py

Write-Host ""
Write-Host "Thank you for playing Lang_World!" -ForegroundColor Cyan
