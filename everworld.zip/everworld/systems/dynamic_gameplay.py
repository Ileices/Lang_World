"""
Dynamic Gameplay - Real-time events, emergent quests, adaptive difficulty
"""

import random
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass
class GameEvent:
    """Real-time game event"""
    event_type: str
    description: str
    trigger_time: float
    duration: float
    effects: Dict[str, Any]
    priority: int = 1


@dataclass
class EmergentQuest:
    """Dynamically generated quest"""
    quest_id: str
    title: str
    description: str
    objectives: List[Dict[str, Any]]
    rewards: Dict[str, Any]
    difficulty: int
    time_limit: Optional[float] = None
    status: str = 'active'


class DynamicGameplay:
    """
    Manages real-time game events, emergent quests, and adaptive content
    """
    
    def __init__(self, ai_game_master=None):
        self.ai_game_master = ai_game_master
        self.real_time_events = RealTimeEventSystem()
        self.adaptive_difficulty = AdaptiveDifficultySystem()
        self.emergent_quests = EmergentQuestGenerator(ai_game_master)
        self.event_history = []
        self.active_quests = []
        
        print("🎮 Dynamic Gameplay System initialized")
    
    def update_game_world(self, player_state: Dict[str, Any], elapsed_time: float):
        """
        AI continuously evolves game world based on player behavior
        
        Args:
            player_state: Current player state
            elapsed_time: Time since last update
        """
        # Analyze player style
        player_profile = self.adaptive_difficulty.analyze_player_style(player_state)
        
        # Generate personalized content
        if random.random() < 0.1:  # 10% chance per update
            personalized_content = self._request_ai_personalization(player_profile)
            if personalized_content:
                self._apply_personalized_changes(personalized_content)
        
        # Update real-time events
        self.real_time_events.update(elapsed_time)
        
        # Check for new emergent quests
        if random.random() < 0.05:  # 5% chance per update
            new_quest = self.emergent_quests.generate_quest(player_state)
            if new_quest:
                self.active_quests.append(new_quest)
                print(f"📜 New quest emerged: {new_quest.title}")
        
        # Update difficulty
        self.adaptive_difficulty.update(player_state)
    
    def _request_ai_personalization(self, player_profile: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Request AI to generate personalized content"""
        if not self.ai_game_master:
            return None
        
        try:
            prompt = f"""
            Generate personalized game content based on player profile:
            {json.dumps(player_profile, indent=2)}
            
            Create one of:
            - A new event that matches player preferences
            - A quest tailored to their play style
            - An NPC encounter that challenges them
            
            Return as JSON with type and content.
            """
            
            response = self.ai_game_master.generate_dynamic_response(
                prompt, "personalization", max_tokens=800
            )
            
            # Extract JSON from response
            directives = self.ai_game_master._extract_directives(response)
            if directives:
                return directives[0]
                
        except Exception as e:
            print(f"⚠️ AI personalization failed: {str(e)}")
        
        return None
    
    def _apply_personalized_changes(self, content: Dict[str, Any]):
        """Apply personalized content to game"""
        content_type = content.get('type', '')
        
        if content_type == 'event':
            event = GameEvent(
                event_type='personalized',
                description=content.get('description', ''),
                trigger_time=time.time(),
                duration=content.get('duration', 60.0),
                effects=content.get('effects', {}),
                priority=content.get('priority', 1)
            )
            self.real_time_events.add_event(event)
            
        elif content_type == 'quest':
            # Add quest (simplified)
            print(f"✨ Personalized quest added: {content.get('title', 'Mystery Quest')}")
    
    def get_active_events(self) -> List[GameEvent]:
        """Get currently active events"""
        return self.real_time_events.get_active_events()
    
    def get_active_quests(self) -> List[EmergentQuest]:
        """Get active quests"""
        return [q for q in self.active_quests if q.status == 'active']
    
    def complete_quest(self, quest_id: str) -> bool:
        """Mark quest as completed"""
        for quest in self.active_quests:
            if quest.quest_id == quest_id and quest.status == 'active':
                quest.status = 'completed'
                print(f"✅ Quest completed: {quest.title}")
                return True
        return False


class RealTimeEventSystem:
    """Manages real-time game events"""
    
    def __init__(self):
        self.active_events = []
        self.event_schedule = []
        
    def add_event(self, event: GameEvent):
        """Add a new event"""
        self.active_events.append(event)
    
    def update(self, elapsed_time: float):
        """Update events (remove expired ones)"""
        current_time = time.time()
        self.active_events = [
            event for event in self.active_events
            if current_time - event.trigger_time < event.duration
        ]
    
    def get_active_events(self) -> List[GameEvent]:
        """Get all active events"""
        return self.active_events


class AdaptiveDifficultySystem:
    """Adapts game difficulty based on player performance"""
    
    def __init__(self):
        self.difficulty_multiplier = 1.0
        self.performance_history = []
        self.adjustment_threshold = 5  # Number of encounters before adjusting
        
    def analyze_player_style(self, player_state: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze player's play style"""
        return {
            'level': player_state.get('level', 1),
            'combat_frequency': 'high',  # Would track this over time
            'exploration_tendency': 'moderate',
            'risk_taking': 'balanced',
            'preferred_content': ['combat', 'exploration']
        }
    
    def update(self, player_state: Dict[str, Any]):
        """Update difficulty based on player performance"""
        # Track performance
        self.performance_history.append({
            'timestamp': time.time(),
            'health_percent': player_state.get('health', 100) / player_state.get('max_health', 100),
            'recent_deaths': 0  # Would track this
        })
        
        # Keep only recent history
        if len(self.performance_history) > 50:
            self.performance_history = self.performance_history[-50:]
        
        # Adjust difficulty if enough data
        if len(self.performance_history) >= self.adjustment_threshold:
            avg_health = sum(p['health_percent'] for p in self.performance_history[-10:]) / 10
            
            if avg_health < 0.3:
                # Player struggling, reduce difficulty
                self.difficulty_multiplier = max(0.7, self.difficulty_multiplier - 0.1)
                print(f"⚖️ Difficulty adjusted down to {self.difficulty_multiplier:.1f}x")
            elif avg_health > 0.8:
                # Player doing too well, increase difficulty
                self.difficulty_multiplier = min(1.5, self.difficulty_multiplier + 0.1)
                print(f"⚖️ Difficulty adjusted up to {self.difficulty_multiplier:.1f}x")
    
    def get_difficulty_multiplier(self) -> float:
        """Get current difficulty multiplier"""
        return self.difficulty_multiplier


class EmergentQuestGenerator:
    """Generates quests dynamically based on game state"""
    
    def __init__(self, ai_game_master=None):
        self.ai_game_master = ai_game_master
        self.quest_counter = 0
        self.quest_templates = [
            {
                'type': 'exploration',
                'title': 'Discover the {location}',
                'objectives': [{'type': 'explore', 'target': 'region'}]
            },
            {
                'type': 'combat',
                'title': 'Defeat {enemy_count} {enemy_type}',
                'objectives': [{'type': 'kill', 'count': 5}]
            },
            {
                'type': 'collection',
                'title': 'Gather {item_count} {item_name}',
                'objectives': [{'type': 'collect', 'count': 10}]
            },
            {
                'type': 'mystery',
                'title': 'Uncover the Secret of {mystery_location}',
                'objectives': [{'type': 'investigate', 'target': 'location'}]
            }
        ]
    
    def generate_quest(self, player_state: Dict[str, Any]) -> Optional[EmergentQuest]:
        """Generate a new quest based on player state"""
        self.quest_counter += 1
        quest_id = f"quest_{self.quest_counter}"
        
        # Try AI generation first
        if self.ai_game_master and random.random() < 0.5:
            ai_quest = self._generate_ai_quest(player_state, quest_id)
            if ai_quest:
                return ai_quest
        
        # Fallback to template-based generation
        template = random.choice(self.quest_templates)
        
        # Fill template
        title = self._fill_quest_template(template['title'], player_state)
        description = f"A new challenge awaits in your journey through the Omniverse."
        
        quest = EmergentQuest(
            quest_id=quest_id,
            title=title,
            description=description,
            objectives=template['objectives'],
            rewards={
                'experience': player_state.get('level', 1) * 100,
                'items': ['random_artifact']
            },
            difficulty=player_state.get('level', 1) + random.randint(0, 2)
        )
        
        return quest
    
    def _generate_ai_quest(self, player_state: Dict[str, Any], quest_id: str) -> Optional[EmergentQuest]:
        """Use AI to generate quest"""
        try:
            prompt = f"""
            Generate an emergent quest for the player:
            Player Level: {player_state.get('level', 1)}
            Player Location: {player_state.get('location', 'unknown')}
            
            Create a quest as JSON:
            {{
              "title": "Quest Title",
              "description": "Detailed description",
              "objectives": [{{"type": "...", "target": "...", "count": 1}}],
              "rewards": {{"experience": 100, "items": []}},
              "difficulty": 1
            }}
            """
            
            response = self.ai_game_master.generate_dynamic_response(
                prompt, "quest_generation", max_tokens=500
            )
            
            directives = self.ai_game_master._extract_directives(response)
            if directives and len(directives) > 0:
                quest_data = directives[0]
                return EmergentQuest(
                    quest_id=quest_id,
                    title=quest_data.get('title', 'Mystery Quest'),
                    description=quest_data.get('description', ''),
                    objectives=quest_data.get('objectives', []),
                    rewards=quest_data.get('rewards', {}),
                    difficulty=quest_data.get('difficulty', 1)
                )
                
        except Exception as e:
            print(f"⚠️ AI quest generation failed: {str(e)}")
        
        return None
    
    def _fill_quest_template(self, template: str, player_state: Dict[str, Any]) -> str:
        """Fill quest template with dynamic content"""
        replacements = {
            '{location}': random.choice(['Void Nexus', 'Crystal Cavern', 'Ancient Ruins']),
            '{enemy_count}': str(random.randint(3, 8)),
            '{enemy_type}': random.choice(['Shadow Beasts', 'Void Entities', 'Corrupted Spirits']),
            '{item_count}': str(random.randint(5, 15)),
            '{item_name}': random.choice(['Void Crystals', 'Ancient Fragments', 'Cosmic Dust']),
            '{mystery_location}': random.choice(['Forgotten Temple', 'Reality Tear', 'Dimensional Rift'])
        }
        
        result = template
        for placeholder, value in replacements.items():
            result = result.replace(placeholder, value)
        
        return result
