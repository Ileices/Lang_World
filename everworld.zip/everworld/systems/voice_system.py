"""
Voice System - Emotional Text-to-Speech for NPCs and narration
"""

import threading
import queue
from typing import Dict, Any, Optional
import time


class VoiceSystem:
    """
    Converts text to speech with emotional tones and personality profiles
    """
    
    def __init__(self):
        self.voice_queue = queue.Queue()
        self.personality_profiles = self._load_personality_profiles()
        self.is_speaking = False
        self.current_speaker = None
        self.tts_engine = None
        
        # Try to initialize TTS
        self._initialize_tts()
        
        # Start voice thread
        self.voice_thread = threading.Thread(target=self._voice_worker, daemon=True)
        self.voice_thread.start()
        
        print("🎙️ Voice System initialized")
    
    def _initialize_tts(self):
        """Initialize text-to-speech engine"""
        try:
            import pyttsx3
            self.tts_engine = pyttsx3.init()
            
            # Configure voice
            voices = self.tts_engine.getProperty('voices')
            if voices:
                # Try to find a good voice
                self.tts_engine.setProperty('voice', voices[0].id)
            
            # Set properties
            self.tts_engine.setProperty('rate', 150)  # Speed
            self.tts_engine.setProperty('volume', 0.9)  # Volume
            
            print("✅ TTS engine initialized (pyttsx3)")
            
        except ImportError:
            print("⚠️ pyttsx3 not installed - voice system will use text-only mode")
            print("   Install with: pip install pyttsx3")
            self.tts_engine = None
        except Exception as e:
            print(f"⚠️ TTS initialization failed: {str(e)}")
            self.tts_engine = None
    
    def _load_personality_profiles(self) -> Dict[str, Dict[str, Any]]:
        """Load personality profiles for different speakers"""
        return {
            'aetherius': {
                'name': 'AETHERIUS',
                'description': 'The Omniversal Architect - mysterious and wise',
                'emotions': {
                    'neutral': {'pitch': 50, 'rate': 150, 'volume': 0.9},
                    'mysterious': {'pitch': 45, 'rate': 140, 'volume': 0.85},
                    'epic': {'pitch': 55, 'rate': 160, 'volume': 1.0},
                    'concerned': {'pitch': 48, 'rate': 145, 'volume': 0.8},
                    'excited': {'pitch': 60, 'rate': 170, 'volume': 0.95},
                    'ominous': {'pitch': 40, 'rate': 130, 'volume': 0.85}
                }
            },
            'narrator': {
                'name': 'Narrator',
                'description': 'Omniscient narrator',
                'emotions': {
                    'neutral': {'pitch': 50, 'rate': 155, 'volume': 0.85},
                    'dramatic': {'pitch': 52, 'rate': 145, 'volume': 0.9},
                    'urgent': {'pitch': 55, 'rate': 180, 'volume': 0.95}
                }
            },
            'npc_friendly': {
                'name': 'Friendly NPC',
                'description': 'Helpful character',
                'emotions': {
                    'neutral': {'pitch': 55, 'rate': 160, 'volume': 0.9},
                    'happy': {'pitch': 60, 'rate': 170, 'volume': 0.95},
                    'worried': {'pitch': 52, 'rate': 150, 'volume': 0.85}
                }
            },
            'enemy': {
                'name': 'Enemy',
                'description': 'Hostile entity',
                'emotions': {
                    'neutral': {'pitch': 45, 'rate': 150, 'volume': 0.9},
                    'threatening': {'pitch': 40, 'rate': 140, 'volume': 0.95},
                    'enraged': {'pitch': 55, 'rate': 180, 'volume': 1.0}
                }
            }
        }
    
    def speak(self, text: str, speaker: str = "aetherius", emotion: str = "neutral", blocking: bool = False):
        """
        Convert text to speech with emotional tone
        
        Args:
            text: Text to speak
            speaker: Speaker personality (aetherius, narrator, npc_friendly, enemy)
            emotion: Emotional tone (neutral, mysterious, epic, etc.)
            blocking: If True, wait for speech to complete
        """
        if not text or not text.strip():
            return
        
        # Get voice profile
        profile = self.personality_profiles.get(speaker, self.personality_profiles['narrator'])
        emotional_tone = profile['emotions'].get(emotion, profile['emotions']['neutral'])
        
        # Queue speech request
        speech_request = {
            'text': text,
            'speaker': speaker,
            'emotion': emotion,
            'profile': profile,
            'tone': emotional_tone,
            'timestamp': time.time()
        }
        
        self.voice_queue.put(speech_request)
        
        # Wait if blocking
        if blocking:
            while not self.voice_queue.empty() or self.is_speaking:
                time.sleep(0.1)
    
    def speak_async(self, text: str, speaker: str = "aetherius", emotion: str = "neutral"):
        """Non-blocking speech (alias for speak with blocking=False)"""
        self.speak(text, speaker, emotion, blocking=False)
    
    def _voice_worker(self):
        """Background thread that processes speech queue"""
        while True:
            try:
                # Get next speech request (blocks until available)
                request = self.voice_queue.get(timeout=1.0)
                
                self.is_speaking = True
                self.current_speaker = request['speaker']
                
                # Print text (always)
                speaker_name = request['profile']['name']
                emotion_tag = f"[{request['emotion']}]" if request['emotion'] != 'neutral' else ""
                print(f"\n🎭 {speaker_name} {emotion_tag}: {request['text']}\n")
                
                # Speak if TTS available
                if self.tts_engine:
                    self._tts_speak(request['text'], request['tone'])
                
                self.is_speaking = False
                self.current_speaker = None
                
                # Mark task done
                self.voice_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                print(f"❌ Voice worker error: {str(e)}")
                self.is_speaking = False
                self.current_speaker = None
    
    def _tts_speak(self, text: str, tone: Dict[str, Any]):
        """Speak using TTS engine with emotional tone"""
        try:
            # Apply emotional tone
            # Note: pyttsx3 has limited emotion control, mainly rate/volume
            if 'rate' in tone:
                self.tts_engine.setProperty('rate', tone['rate'])
            if 'volume' in tone:
                self.tts_engine.setProperty('volume', tone['volume'])
            
            # Speak
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
            
        except Exception as e:
            print(f"⚠️ TTS error: {str(e)}")
    
    def stop_speaking(self):
        """Stop current speech"""
        if self.tts_engine:
            try:
                self.tts_engine.stop()
            except:
                pass
        
        # Clear queue
        while not self.voice_queue.empty():
            try:
                self.voice_queue.get_nowait()
                self.voice_queue.task_done()
            except queue.Empty:
                break
        
        self.is_speaking = False
        self.current_speaker = None
    
    def is_busy(self) -> bool:
        """Check if voice system is currently speaking"""
        return self.is_speaking or not self.voice_queue.empty()
    
    def wait_until_done(self, timeout: float = 30.0):
        """Wait until all queued speech is done"""
        start_time = time.time()
        while self.is_busy():
            if time.time() - start_time > timeout:
                print("⚠️ Voice system wait timeout")
                break
            time.sleep(0.1)
    
    def narrate(self, text: str, dramatic: bool = False):
        """Narrate game events"""
        emotion = 'dramatic' if dramatic else 'neutral'
        self.speak(text, 'narrator', emotion)
    
    def aetherius_speaks(self, text: str, emotion: str = "mysterious"):
        """AETHERIUS speaks (convenience method)"""
        self.speak(text, 'aetherius', emotion)
    
    def npc_speaks(self, text: str, emotion: str = "neutral"):
        """NPC speaks (convenience method)"""
        self.speak(text, 'npc_friendly', emotion)
    
    def enemy_speaks(self, text: str, emotion: str = "threatening"):
        """Enemy speaks (convenience method)"""
        self.speak(text, 'enemy', emotion)
