"""
AI Learning System - Learns player preferences and adapts content
"""

import json
import time
from typing import Dict, List, Any, Optional
from pathlib import Path
from collections import Counter
import sqlite3


class AILearningSystem:
    """
    Continuously learns and adapts to player preferences
    """
    
    def __init__(self):
        self.memory_db_path = Path("game_world/ai_memory/ai_learning.db")
        self.memory_db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.conn = sqlite3.connect(str(self.memory_db_path), check_same_thread=False)
        self.preference_analyzer = PreferenceAnalyzer()
        self.adaptation_engine = AdaptationEngine()
        self.player_profile = self._load_or_create_profile()
        
        self._initialize_database()
        
        print("🧠 AI Learning System initialized")
    
    def _initialize_database(self):
        """Initialize learning database"""
        cursor = self.conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS player_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL,
                action_type TEXT,
                action_data TEXT,
                context TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS emotional_responses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL,
                trigger_event TEXT,
                inferred_emotion TEXT,
                confidence REAL
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS content_preferences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_type TEXT,
                content_id TEXT,
                engagement_score REAL,
                timestamp REAL
            )
        ''')
        
        self.conn.commit()
    
    def _load_or_create_profile(self) -> Dict[str, Any]:
        """Load or create player profile"""
        profile_path = Path("game_world/ai_memory/player_preferences.json")
        
        if profile_path.exists():
            try:
                with open(profile_path, 'r') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            'play_style': 'unknown',
            'preferred_content': [],
            'avoided_content': [],
            'interaction_patterns': {},
            'decision_history': [],
            'learning_phase': 'initial',
            'confidence_level': 0.0
        }
    
    def record_action(self, action_type: str, action_data: Dict[str, Any], context: Dict[str, Any]):
        """Record a player action"""
        cursor = self.conn.cursor()
        cursor.execute(
            'INSERT INTO player_actions (timestamp, action_type, action_data, context) VALUES (?, ?, ?, ?)',
            (time.time(), action_type, json.dumps(action_data), json.dumps(context))
        )
        self.conn.commit()
    
    def record_emotional_response(self, trigger_event: str, inferred_emotion: str, confidence: float):
        """Record inferred emotional response"""
        cursor = self.conn.cursor()
        cursor.execute(
            'INSERT INTO emotional_responses (timestamp, trigger_event, inferred_emotion, confidence) VALUES (?, ?, ?, ?)',
            (time.time(), trigger_event, inferred_emotion, confidence)
        )
        self.conn.commit()
    
    def record_content_engagement(self, content_type: str, content_id: str, engagement_score: float):
        """Record engagement with content"""
        cursor = self.conn.cursor()
        cursor.execute(
            'INSERT INTO content_preferences (content_type, content_id, engagement_score, timestamp) VALUES (?, ?, ?, ?)',
            (content_type, content_id, engagement_score, time.time())
        )
        self.conn.commit()
    
    def update_player_model(self, player_actions: List[Dict[str, Any]], 
                           emotional_responses: Optional[List[Dict[str, Any]]] = None):
        """
        Continuously learn and adapt to player preferences
        
        Args:
            player_actions: Recent player actions
            emotional_responses: Inferred emotional responses (optional)
        """
        # Analyze patterns in player behavior
        patterns = self.preference_analyzer.detect_patterns(player_actions)
        
        # Update player profile
        self._update_player_profile(patterns)
        
        # Generate adaptive content suggestions
        adaptive_content = self.adaptation_engine.generate_adaptive_elements(
            self.player_profile, patterns
        )
        
        # Increase confidence over time
        self.player_profile['confidence_level'] = min(
            1.0,
            self.player_profile['confidence_level'] + 0.01
        )
        
        # Save updated profile
        self._save_player_profile()
        
        return adaptive_content
    
    def _update_player_profile(self, patterns: Dict[str, Any]):
        """Update player profile based on detected patterns"""
        # Update play style
        if 'play_style' in patterns:
            self.player_profile['play_style'] = patterns['play_style']
        
        # Update preferred content
        if 'preferred_content' in patterns:
            for content in patterns['preferred_content']:
                if content not in self.player_profile['preferred_content']:
                    self.player_profile['preferred_content'].append(content)
        
        # Update avoided content
        if 'avoided_content' in patterns:
            for content in patterns['avoided_content']:
                if content not in self.player_profile['avoided_content']:
                    self.player_profile['avoided_content'].append(content)
        
        # Update interaction patterns
        if 'interaction_patterns' in patterns:
            self.player_profile['interaction_patterns'].update(patterns['interaction_patterns'])
        
        # Update learning phase
        action_count = self._get_total_actions()
        if action_count < 50:
            self.player_profile['learning_phase'] = 'initial'
        elif action_count < 200:
            self.player_profile['learning_phase'] = 'developing'
        else:
            self.player_profile['learning_phase'] = 'established'
    
    def _get_total_actions(self) -> int:
        """Get total number of recorded actions"""
        cursor = self.conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM player_actions')
        result = cursor.fetchone()
        return result[0] if result else 0
    
    def _save_player_profile(self):
        """Save player profile to disk"""
        profile_path = Path("game_world/ai_memory/player_preferences.json")
        with open(profile_path, 'w') as f:
            json.dump(self.player_profile, f, indent=2)
    
    def get_player_profile(self) -> Dict[str, Any]:
        """Get current player profile"""
        return self.player_profile.copy()
    
    def get_content_recommendations(self) -> List[str]:
        """Get recommended content types based on learning"""
        return self.player_profile.get('preferred_content', [])[:5]


class PreferenceAnalyzer:
    """Analyzes player actions to detect preferences"""
    
    def detect_patterns(self, player_actions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Detect patterns in player behavior
        
        Returns:
            Dictionary of detected patterns
        """
        if not player_actions:
            return {}
        
        patterns = {}
        
        # Analyze action types
        action_types = [a.get('action_type', 'unknown') for a in player_actions]
        action_counts = Counter(action_types)
        
        # Determine play style based on dominant actions
        if action_counts.get('combat', 0) > len(player_actions) * 0.5:
            patterns['play_style'] = 'combat_focused'
        elif action_counts.get('exploration', 0) > len(player_actions) * 0.5:
            patterns['play_style'] = 'explorer'
        elif action_counts.get('dialogue', 0) > len(player_actions) * 0.3:
            patterns['play_style'] = 'story_focused'
        else:
            patterns['play_style'] = 'balanced'
        
        # Detect preferred content
        patterns['preferred_content'] = []
        if action_counts.get('combat', 0) > 5:
            patterns['preferred_content'].append('combat')
        if action_counts.get('exploration', 0) > 5:
            patterns['preferred_content'].append('exploration')
        if action_counts.get('dialogue', 0) > 5:
            patterns['preferred_content'].append('dialogue')
        
        # Detect interaction patterns
        patterns['interaction_patterns'] = {
            'combat_frequency': action_counts.get('combat', 0) / max(1, len(player_actions)),
            'exploration_frequency': action_counts.get('exploration', 0) / max(1, len(player_actions)),
            'dialogue_frequency': action_counts.get('dialogue', 0) / max(1, len(player_actions))
        }
        
        return patterns


class AdaptationEngine:
    """Generates adaptive content based on player profile"""
    
    def generate_adaptive_elements(self, player_profile: Dict[str, Any], 
                                   patterns: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate adaptive content elements
        
        Returns:
            Dictionary of adaptive content suggestions
        """
        adaptive_content = {
            'suggested_content_types': [],
            'difficulty_adjustments': {},
            'narrative_preferences': [],
            'interaction_suggestions': []
        }
        
        play_style = player_profile.get('play_style', 'unknown')
        
        # Content suggestions based on play style
        if play_style == 'combat_focused':
            adaptive_content['suggested_content_types'].extend([
                'challenging_enemies', 'boss_encounters', 'combat_events'
            ])
            adaptive_content['difficulty_adjustments']['enemy_strength'] = 1.2
            
        elif play_style == 'explorer':
            adaptive_content['suggested_content_types'].extend([
                'hidden_areas', 'secret_paths', 'mysterious_locations'
            ])
            adaptive_content['narrative_preferences'].append('discovery_focused')
            
        elif play_style == 'story_focused':
            adaptive_content['suggested_content_types'].extend([
                'npc_encounters', 'lore_fragments', 'dialogue_heavy_events'
            ])
            adaptive_content['narrative_preferences'].append('character_driven')
        
        # Interaction suggestions based on learning phase
        learning_phase = player_profile.get('learning_phase', 'initial')
        
        if learning_phase == 'initial':
            adaptive_content['interaction_suggestions'].append('tutorial_hints')
        elif learning_phase == 'developing':
            adaptive_content['interaction_suggestions'].append('moderate_guidance')
        else:
            adaptive_content['interaction_suggestions'].append('minimal_guidance')
        
        return adaptive_content
