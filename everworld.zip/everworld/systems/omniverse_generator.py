"""
Omniverse Generator - Infinite Procedural Universe Generation
Creates cosmic-scale regions with AI enhancement
"""

import random
import json
import math
from typing import Dict, List, Any, Tuple
from pathlib import Path
import hashlib


class OmniverseGenerator:
    """
    Generates infinite, interconnected regions with cosmic significance
    """
    
    def __init__(self, ai_game_master=None):
        self.seed = self._generate_cosmic_seed()
        self.ai_game_master = ai_game_master
        self.depth_scaling = ExponentialScaling()
        self.region_connector = QuantumRegionConnector()
        self.biome_generator = BiomeGenerator()
        
        # Cache for generated regions
        self.region_cache = {}
        
        print(f"🌌 Omniverse Generator initialized (seed: {self.seed})")
    
    def _generate_cosmic_seed(self) -> int:
        """Generate unique cosmic seed"""
        import time
        return int(time.time() * 1000) % 100000000
    
    def generate_region(self, x: int, y: int, depth: int, player_level: int = 1) -> Dict[str, Any]:
        """
        Generate a region with cosmic significance
        
        Args:
            x, y: Region coordinates
            depth: Depth level (0 = surface, higher = deeper/harder)
            player_level: Current player level for difficulty scaling
            
        Returns:
            Complete region data with AI enhancements
        """
        region_key = f"{x}_{y}_{depth}"
        
        # Check cache
        if region_key in self.region_cache:
            return self.region_cache[region_key]
        
        # Set deterministic seed for this region
        region_seed = self._calculate_region_seed(x, y, depth)
        random.seed(region_seed)
        
        # Generate base region
        base_region = {
            'coordinates': {'x': x, 'y': y, 'depth': depth},
            'region_key': region_key,
            'cosmic_signature': self._generate_cosmic_signature(x, y, depth),
            'terrain': self.biome_generator.generate_biome(x, y, depth),
            'dimensional_properties': self._calculate_dimensional_properties(depth),
            'difficulty': self._calculate_difficulty(depth, player_level),
            'entities': self._generate_base_entities(depth, player_level),
            'features': self._generate_base_features(depth),
            'quantum_connections': self._establish_multiversal_links(x, y, depth),
            'discovery_state': 'undiscovered',
            'time_of_creation': self._get_cosmic_time()
        }
        
        # AI enhancement (if available)
        if self.ai_game_master:
            try:
                ai_enhancements = self.ai_game_master.generate_region_enhancement(base_region)
                base_region.update(ai_enhancements)
            except Exception as e:
                print(f"⚠️ AI enhancement failed: {str(e)}")
        
        # Save region to disk
        self._save_region(base_region)
        
        # Cache
        self.region_cache[region_key] = base_region
        
        return base_region
    
    def _calculate_region_seed(self, x: int, y: int, depth: int) -> int:
        """Calculate deterministic seed for region"""
        return self.seed + (x * 7919) + (y * 6553) + (depth * 4987)
    
    def _generate_cosmic_signature(self, x: int, y: int, depth: int) -> str:
        """Generate unique cosmic signature for region"""
        data = f"{x},{y},{depth},{self.seed}"
        hash_obj = hashlib.md5(data.encode())
        return hash_obj.hexdigest()[:12].upper()
    
    def _calculate_dimensional_properties(self, depth: int) -> Dict[str, Any]:
        """Calculate dimensional properties based on depth"""
        return {
            'reality_stability': max(0.1, 1.0 - (depth * 0.05)),
            'temporal_flux': depth * 0.1,
            'dimensional_thinning': depth * 0.08,
            'void_proximity': min(1.0, depth * 0.12),
            'magic_intensity': 0.5 + (depth * 0.15)
        }
    
    def _calculate_difficulty(self, depth: int, player_level: int) -> int:
        """Calculate region difficulty"""
        base_difficulty = depth + random.randint(1, 3)
        level_scaling = max(1, player_level // 5)
        return base_difficulty + level_scaling
    
    def _generate_base_entities(self, depth: int, player_level: int) -> List[Dict[str, Any]]:
        """Generate base entities for region"""
        entities = []
        num_entities = random.randint(0, 2 + depth)
        
        for i in range(num_entities):
            entity_type = random.choice(['enemy', 'neutral', 'friendly'])
            entity = {
                'id': f"entity_{i}",
                'type': entity_type,
                'name': self._generate_entity_name(depth, entity_type),
                'health': 20 + (depth * 15) + (player_level * 5),
                'max_health': 20 + (depth * 15) + (player_level * 5),
                'attack': 5 + (depth * 3) + (player_level * 2),
                'defense': 2 + depth + player_level,
                'level': depth + player_level,
                'position': {'x': random.randint(0, 4), 'y': random.randint(0, 4)},
                'behavior': random.choice(['aggressive', 'passive', 'defensive', 'territorial']),
                'loot_table': self._generate_loot_table(depth)
            }
            entities.append(entity)
        
        return entities
    
    def _generate_entity_name(self, depth: int, entity_type: str) -> str:
        """Generate entity name based on depth and type"""
        prefixes = ['Ancient', 'Void', 'Crystal', 'Shadow', 'Ethereal', 'Cosmic']
        suffixes = ['Wyrm', 'Sentinel', 'Reaver', 'Guardian', 'Wanderer', 'Entity']
        
        if depth == 0:
            return random.choice(['Forest Sprite', 'Wild Boar', 'Wandering Merchant', 'Lost Traveler'])
        elif depth < 5:
            return f"{random.choice(prefixes)} {random.choice(suffixes)}"
        else:
            return f"Depth {depth} {random.choice(prefixes)} {random.choice(suffixes)}"
    
    def _generate_loot_table(self, depth: int) -> List[Dict[str, Any]]:
        """Generate loot table for entity"""
        loot = []
        num_items = random.randint(1, 3)
        
        for _ in range(num_items):
            item = {
                'name': f"Depth {depth} Artifact",
                'type': random.choice(['weapon', 'armor', 'consumable', 'material']),
                'value': depth * 10 + random.randint(5, 50),
                'rarity': self._determine_rarity(depth)
            }
            loot.append(item)
        
        return loot
    
    def _determine_rarity(self, depth: int) -> str:
        """Determine item rarity based on depth"""
        roll = random.random() + (depth * 0.05)
        
        if roll > 0.95:
            return 'legendary'
        elif roll > 0.85:
            return 'epic'
        elif roll > 0.70:
            return 'rare'
        elif roll > 0.50:
            return 'uncommon'
        else:
            return 'common'
    
    def _generate_base_features(self, depth: int) -> List[str]:
        """Generate base environmental features"""
        features = []
        
        # Depth-specific features
        if depth == 0:
            possible = ['trees', 'rocks', 'stream', 'cave_entrance', 'abandoned_camp']
        elif depth < 5:
            possible = ['crystals', 'ancient_ruins', 'mysterious_obelisk', 'portal_fragment', 'void_tear']
        else:
            possible = ['reality_distortion', 'temporal_anomaly', 'dimensional_rift', 'cosmic_altar']
        
        num_features = random.randint(2, 4)
        features.extend(random.sample(possible, min(num_features, len(possible))))
        
        # Special features
        if random.random() < 0.3:
            features.append('treasure_chest')
        if random.random() < 0.2 + (depth * 0.05):
            features.append('portal')
        if random.random() < 0.15:
            features.append('npc_encounter')
        
        return features
    
    def _establish_multiversal_links(self, x: int, y: int, depth: int) -> Dict[str, Any]:
        """Establish quantum connections to other regions"""
        return {
            'stability': max(0.5, 1.0 - (depth * 0.1)),
            'connected_regions': [],  # To be populated as player explores
            'portal_destinations': self._generate_portal_destinations(x, y, depth)
        }
    
    def _generate_portal_destinations(self, x: int, y: int, depth: int) -> List[Dict[str, int]]:
        """Generate possible portal destinations"""
        destinations = []
        
        # Portals can go deeper or to adjacent regions at same depth
        if random.random() < 0.7:
            destinations.append({'x': x, 'y': y, 'depth': depth + 1})
        
        if random.random() < 0.3:
            dx = random.randint(-2, 2)
            dy = random.randint(-2, 2)
            destinations.append({'x': x + dx, 'y': y + dy, 'depth': depth})
        
        return destinations
    
    def _get_cosmic_time(self) -> int:
        """Get current cosmic time"""
        import time
        return int(time.time())
    
    def _save_region(self, region: Dict[str, Any]):
        """Save region to disk"""
        try:
            region_key = region['region_key']
            region_dir = Path(f"game_world/regions/region_{region_key}")
            region_dir.mkdir(parents=True, exist_ok=True)
            
            # Save terrain data
            with open(region_dir / "terrain.json", 'w') as f:
                json.dump(region, f, indent=2)
            
            # Save entities separately
            if region.get('entities'):
                with open(region_dir / "entities.json", 'w') as f:
                    json.dump(region['entities'], f, indent=2)
            
            # Create event log
            event_log = region_dir / "events.log"
            if not event_log.exists():
                event_log.write_text(f"Region created at cosmic time {region['time_of_creation']}\n")
                
        except Exception as e:
            print(f"❌ Error saving region: {str(e)}")


class ExponentialScaling:
    """Handles exponential difficulty/reward scaling with depth"""
    
    def scale_value(self, base_value: float, depth: int, exponent: float = 1.2) -> float:
        """Scale a value exponentially with depth"""
        return base_value * (exponent ** depth)


class QuantumRegionConnector:
    """Manages quantum connections between regions"""
    
    def establish_connection(self, region_a: Dict, region_b: Dict) -> Dict[str, Any]:
        """Establish quantum connection between regions"""
        return {
            'type': 'quantum_entanglement',
            'stability': random.uniform(0.6, 1.0),
            'traversable': random.random() > 0.3
        }


class BiomeGenerator:
    """Generates biomes based on coordinates"""
    
    def __init__(self):
        self.biomes = {
            0: ['forest', 'plains', 'hills', 'swamp', 'tundra', 'desert', 'village'],
            1: ['dark_forest', 'cave', 'underground_lake', 'ancient_tomb', 'forgotten_temple'],
            2: ['deep_cave', 'crystal_cavern', 'void_chamber', 'corrupted_grove'],
            3: ['abyss', 'void_realm', 'reality_fracture', 'dimensional_nexus'],
            4: ['pure_void', 'cosmic_void', 'reality_edge', 'creation_point']
        }
    
    def generate_biome(self, x: int, y: int, depth: int) -> str:
        """Generate biome type based on location"""
        # Use coordinates for deterministic biome selection
        random.seed(x * 1000 + y * 100 + depth)
        
        depth_category = min(depth, 4)
        biome_list = self.biomes[depth_category]
        
        return random.choice(biome_list)
