import pygame
import json
import sqlite3
import random
import math
import requests
import time
from enum import Enum
from typing import Dict, List, Any, Optional

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800
TILE_SIZE = 64
FPS = 60

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BROWN = (139, 69, 19)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
GRAY = (128, 128, 128)

class GameState(Enum):
    MAIN_MENU = 0
    PLAYING = 1
    COMBAT = 2
    DIALOGUE = 3
    INVENTORY = 4

class OllamaIntegration:
    def __init__(self, base_url="http://localhost:11434"):
        self.base_url = base_url
        self.conversation_history = []
        
    def generate_response(self, prompt, model="llama2", max_tokens=20000):
        """Generate response from Ollama"""
        try:
            full_prompt = self._build_prompt(prompt)
            
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": model,
                    "prompt": full_prompt,
                    "stream": False,
                    "options": {
                        "num_predict": max_tokens,
                        "temperature": 0.7
                    }
                },
                timeout=1000
            )
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get("response", "").strip()
                self.conversation_history.append({"role": "assistant", "content": response_text})
                return response_text
            else:
                return f"Error: {response.status_code}"
                
        except Exception as e:
            return f"Ollama error: {str(e)}"
    
    def _build_prompt(self, user_input):
        """Build conversation context"""
        context = """You are a mystical wizard guide in a fantasy RPG. You have a wise, mysterious personality. 
        Respond to the player naturally while also generating game content when appropriate.
        
        When generating game content, use these JSON formats:
        
        For enemies: {"type": "enemy", "name": "string", "health": int, "attack": int, "defense": int, "abilities": ["string"]}
        For items: {"type": "item", "name": "string", "description": "string", "value": int, "rarity": "common|uncommon|rare|epic"}
        For locations: {"type": "location", "name": "string", "description": "string", "difficulty": int, "features": ["string"]}
        For lore: {"type": "lore", "title": "string", "content": "string", "importance": "low|medium|high"}
        
        Mix natural conversation with structured game content generation."""
        
        prompt_parts = [context]
        
        # Add conversation history
        for msg in self.conversation_history[-6:]:  # Keep last 6 messages for context
            role = "User" if msg["role"] == "user" else "Wizard"
            prompt_parts.append(f"{role}: {msg['content']}")
        
        prompt_parts.append(f"User: {user_input}")
        prompt_parts.append("Wizard:")
        
        return "\n".join(prompt_parts)
    
    def parse_game_content(self, response):
        """Extract structured game content from LLM response"""
        try:
            # Look for JSON blocks in the response
            lines = response.split('\n')
            for line in lines:
                line = line.strip()
                if line.startswith('{') and line.endswith('}'):
                    content = json.loads(line)
                    return content
        except:
            pass
        return None

class WorldGenerator:
    def __init__(self):
        self.seed = random.randint(1, 10000)
        self.regions = {}
        
    def generate_region(self, x, y, depth=0):
        """Generate a region at given coordinates"""
        region_key = f"{x},{y}"
        if region_key in self.regions:
            return self.regions[region_key]
            
        random.seed(self.seed + x * 1000 + y * 100 + depth)
        
        # Terrain types based on depth
        if depth == 0:
            terrain_types = ['forest', 'plains', 'hills', 'village']
        else:
            terrain_types = ['cave', 'dungeon', 'ruins', 'crypt']
            
        terrain = random.choice(terrain_types)
        
        region = {
            'x': x, 'y': y, 'depth': depth,
            'terrain': terrain,
            'discovered': False,
            'entities': self._generate_entities(depth),
            'features': self._generate_features(terrain, depth),
            'difficulty': depth + random.randint(1, 3)
        }
        
        self.regions[region_key] = region
        return region
    
    def _generate_entities(self, depth):
        """Generate entities for a region"""
        entities = []
        num_entities = random.randint(0, 3 + depth)
        
        for _ in range(num_entities):
            entity = {
                'type': 'enemy',
                'name': f"Depth {depth} Creature",
                'health': 20 + depth * 10,
                'attack': 5 + depth * 2,
                'defense': 2 + depth,
                'x': random.randint(0, 4),
                'y': random.randint(0, 4)
            }
            entities.append(entity)
            
        return entities
    
    def _generate_features(self, terrain, depth):
        """Generate terrain features"""
        features = []
        if terrain in ['forest', 'plains']:
            features.extend(['trees', 'rocks', 'stream'])
        elif terrain in ['cave', 'dungeon']:
            features.extend(['torches', 'rubble', 'ancient markings'])
            
        if random.random() < 0.3:
            features.append('treasure_chest')
        if random.random() < 0.2:
            features.append('portal')
            
        return features

class Player:
    def __init__(self, name):
        self.name = name
        self.health = 100
        self.max_health = 100
        self.attack = 10
        self.defense = 5
        self.level = 1
        self.experience = 0
        self.inventory = []
        self.x = 0
        self.y = 0
        self.region_x = 0
        self.region_y = 0
        self.depth = 0
        
    def move(self, dx, dy, world):
        """Move player and handle world transitions"""
        self.x += dx
        self.y += dy
        
        # Handle region transitions
        if self.x < 0:
            self.region_x -= 1
            self.x = 4
        elif self.x > 4:
            self.region_x += 1
            self.x = 0
        if self.y < 0:
            self.region_y -= 1
            self.y = 4
        elif self.y > 4:
            self.region_y += 1
            self.y = 0
            
        # Generate new region if needed
        world.generate_region(self.region_x, self.region_y, self.depth)
        
    def add_experience(self, amount):
        """Add experience and handle level ups"""
        self.experience += amount
        if self.experience >= self.level * 100:
            self.level_up()
            
    def level_up(self):
        """Handle player level up"""
        self.level += 1
        self.max_health += 20
        self.health = self.max_health
        self.attack += 5
        self.defense += 2
        self.experience = 0

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Ollama RPG")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        
        self.state = GameState.MAIN_MENU
        self.ollama = OllamaIntegration()
        self.world = WorldGenerator()
        self.player = None
        self.current_region = None
        self.current_enemy = None
        self.dialogue_text = ""
        self.input_text = ""
        self.game_log = []
        
        # Initialize database
        self.init_database()
        
    def init_database(self):
        """Initialize SQLite database for game state"""
        self.conn = sqlite3.connect('game_state.db', check_same_thread=False)
        cursor = self.conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS game_events (
                id INTEGER PRIMARY KEY,
                timestamp TEXT,
                event_type TEXT,
                event_data TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS player_progress (
                id INTEGER PRIMARY KEY,
                depth INTEGER,
                regions_discovered INTEGER,
                enemies_defeated INTEGER
            )
        ''')
        
        self.conn.commit()
    
    def log_event(self, event_type, event_data):
        """Log game events to database"""
        cursor = self.conn.cursor()
        cursor.execute(
            'INSERT INTO game_events (timestamp, event_type, event_data) VALUES (?, ?, ?)',
            (time.ctime(), event_type, json.dumps(event_data))
        )
        self.conn.commit()
        
    def handle_events(self):
        """Handle pygame events"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
                
            if self.state == GameState.MAIN_MENU:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        self.start_new_game()
                    elif event.key == pygame.K_ESCAPE:
                        return False
                        
            elif self.state == GameState.DIALOGUE:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and self.input_text.strip():
                        self.handle_dialogue_input()
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_text = self.input_text[:-1]
                    elif event.key == pygame.K_ESCAPE:
                        self.state = GameState.PLAYING
                    else:
                        self.input_text += event.unicode
                        
            elif self.state == GameState.PLAYING:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_c:  # Dialogue mode
                        self.state = GameState.DIALOGUE
                        self.input_text = ""
                    elif event.key == pygame.K_i:  # Inventory
                        self.state = GameState.INVENTORY
                    elif event.key == pygame.K_TAB:  # Generate new content with Ollama
                        self.generate_world_content()
                        
            elif self.state == GameState.COMBAT:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        self.player_attack()
                    elif event.key == pygame.K_r:  # Run away
                        self.state = GameState.PLAYING
                        self.add_game_log("You escaped from combat!")
                        
            elif self.state == GameState.INVENTORY:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_i or event.key == pygame.K_ESCAPE:
                        self.state = GameState.PLAYING
        
        # Continuous key presses for movement
        if self.state == GameState.PLAYING:
            keys = pygame.key.get_pressed()
            dx, dy = 0, 0
            if keys[pygame.K_w]: dy = -1
            if keys[pygame.K_s]: dy = 1
            if keys[pygame.K_a]: dx = -1
            if keys[pygame.K_d]: dx = 1
            
            if dx != 0 or dy != 0:
                old_x, old_y = self.player.x, self.player.y
                self.player.move(dx, dy, self.world)
                self.check_encounters(old_x, old_y)
                
        return True
    
    def start_new_game(self):
        """Start a new game"""
        self.state = GameState.DIALOGUE
        self.dialogue_text = "Greetings, traveler! I am the Wizard of this realm. What is your name?"
        self.input_text = ""
        
    def handle_dialogue_input(self):
        """Handle player input in dialogue mode"""
        player_input = self.input_text.strip()
        self.input_text = ""
        
        if not self.player:
            # First interaction - set player name
            self.player = Player(player_input)
            self.current_region = self.world.generate_region(0, 0, 0)
            response = f"Welcome, {player_input}! You stand at the edge of an infinite world. I shall guide you. Speak to me whenever you need advice or wish to shape your journey. Press TAB to generate new world content, C to chat, I for inventory."
        else:
            # Regular dialogue
            response = self.ollama.generate_response(player_input)
            
        self.dialogue_text = response
        self.log_event("dialogue", {"input": player_input, "response": response})
        
        # Parse any game content from the response
        game_content = self.ollama.parse_game_content(response)
        if game_content:
            self.handle_game_content(game_content)
            
        # Return to playing after dialogue
        self.state = GameState.PLAYING
    
    def handle_game_content(self, content):
        """Handle structured game content from Ollama"""
        content_type = content.get('type')
        
        if content_type == 'enemy':
            self.spawn_enemy(content)
        elif content_type == 'item':
            self.add_item(content)
        elif content_type == 'location':
            self.add_location(content)
        elif content_type == 'lore':
            self.add_lore(content)
    
    def spawn_enemy(self, enemy_data):
        """Spawn an enemy from Ollama generation"""
        self.current_enemy = enemy_data
        self.state = GameState.COMBAT
        self.add_game_log(f"A wild {enemy_data['name']} appears!")
    
    def add_item(self, item_data):
        """Add an item from Ollama generation"""
        self.player.inventory.append(item_data)
        self.add_game_log(f"Found: {item_data['name']} - {item_data['description']}")
    
    def add_game_log(self, message):
        """Add message to game log"""
        self.game_log.append(message)
        if len(self.game_log) > 10:
            self.game_log.pop(0)
    
    def check_encounters(self, old_x, old_y):
        """Check for encounters when moving"""
        if not self.current_region:
            return
            
        # Check for entities in current position
        for entity in self.current_region['entities']:
            if entity['x'] == self.player.x and entity['y'] == self.player.y:
                self.current_enemy = entity
                self.state = GameState.COMBAT
                self.add_game_log(f"Encountered {entity['name']}!")
                return
                
        # Check for portals
        if 'portal' in self.current_region['features']:
            if random.random() < 0.1:  # 10% chance to enter portal
                self.enter_portal()
    
    def enter_portal(self):
        """Enter a portal to deeper levels"""
        self.player.depth += 1
        self.player.region_x = 0
        self.player.region_y = 0
        self.current_region = self.world.generate_region(0, 0, self.player.depth)
        self.add_game_log(f"Entered depth level {self.player.depth}!")
    
    def player_attack(self):
        """Handle player attack in combat"""
        if not self.current_enemy:
            return
            
        damage = max(1, self.player.attack - self.current_enemy.get('defense', 0))
        self.current_enemy['health'] -= damage
        
        self.add_game_log(f"You attack {self.current_enemy['name']} for {damage} damage!")
        
        if self.current_enemy['health'] <= 0:
            self.defeat_enemy()
        else:
            self.enemy_attack()
    
    def enemy_attack(self):
        """Handle enemy attack in combat"""
        if not self.current_enemy:
            return
            
        damage = max(1, self.current_enemy.get('attack', 5) - self.player.defense)
        self.player.health -= damage
        
        self.add_game_log(f"{self.current_enemy['name']} attacks you for {damage} damage!")
        
        if self.player.health <= 0:
            self.game_over()
    
    def defeat_enemy(self):
        """Handle enemy defeat"""
        exp_gain = self.current_enemy.get('attack', 5) * 10
        self.player.add_experience(exp_gain)
        
        self.add_game_log(f"Defeated {self.current_enemy['name']}! Gained {exp_gain} EXP!")
        self.log_event("enemy_defeated", self.current_enemy)
        
        self.current_enemy = None
        self.state = GameState.PLAYING
        
        # Chance to generate new content after victory
        if random.random() < 0.3:
            self.generate_world_content()
    
    def game_over(self):
        """Handle game over"""
        self.add_game_log("You have been defeated...")
        self.state = GameState.MAIN_MENU
        self.log_event("game_over", {"depth": self.player.depth})
    
    def generate_world_content(self):
        """Use Ollama to generate new world content"""
        prompt = f"Generate new game content for depth level {self.player.depth}. Player is at region ({self.player.region_x}, {self.player.region_y})."
        response = self.ollama.generate_response(prompt)
        game_content = self.ollama.parse_game_content(response)
        
        if game_content:
            self.handle_game_content(game_content)
        else:
            self.add_game_log("The wizard murmurs ancient words, but nothing happens...")
    
    def render(self):
        """Render the game"""
        self.screen.fill(BLACK)
        
        if self.state == GameState.MAIN_MENU:
            self.render_main_menu()
        elif self.state == GameState.PLAYING:
            self.render_world()
        elif self.state == GameState.COMBAT:
            self.render_combat()
        elif self.state == GameState.DIALOGUE:
            self.render_dialogue()
        elif self.state == GameState.INVENTORY:
            self.render_inventory()
            
        self.render_ui()
        pygame.display.flip()
    
    def render_main_menu(self):
        """Render main menu"""
        title = self.font.render("Ollama RPG", True, WHITE)
        subtitle = self.small_font.render("Press ENTER to start, ESC to quit", True, WHITE)
        
        self.screen.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 3))
        self.screen.blit(subtitle, (SCREEN_WIDTH // 2 - subtitle.get_width() // 2, SCREEN_HEIGHT // 2))
    
    def render_world(self):
        """Render the game world"""
        if not self.current_region:
            return
            
        # Draw region grid
        for x in range(5):
            for y in range(5):
                rect = pygame.Rect(
                    SCREEN_WIDTH // 2 - (2.5 * TILE_SIZE) + x * TILE_SIZE,
                    SCREEN_HEIGHT // 2 - (2.5 * TILE_SIZE) + y * TILE_SIZE,
                    TILE_SIZE, TILE_SIZE
                )
                pygame.draw.rect(self.screen, GREEN, rect, 1)
                
                # Draw player
                if x == self.player.x and y == self.player.y:
                    pygame.draw.rect(self.screen, BLUE, rect)
                
                # Draw entities
                for entity in self.current_region['entities']:
                    if entity['x'] == x and entity['y'] == y:
                        pygame.draw.rect(self.screen, RED, rect)
    
    def render_combat(self):
        """Render combat screen"""
        if not self.current_enemy:
            return
            
        # Draw enemy
        enemy_text = self.font.render(f"{self.current_enemy['name']}", True, RED)
        health_text = self.small_font.render(f"Health: {self.current_enemy['health']}", True, WHITE)
        
        self.screen.blit(enemy_text, (SCREEN_WIDTH // 2 - enemy_text.get_width() // 2, 200))
        self.screen.blit(health_text, (SCREEN_WIDTH // 2 - health_text.get_width() // 2, 250))
        
        # Draw combat instructions
        instructions = self.small_font.render("Press SPACE to attack, R to run", True, WHITE)
        self.screen.blit(instructions, (SCREEN_WIDTH // 2 - instructions.get_width() // 2, 350))
    
    def render_dialogue(self):
        """Render dialogue screen"""
        # Draw dialogue text
        lines = self.wrap_text(self.dialogue_text, self.small_font, SCREEN_WIDTH - 100)
        for i, line in enumerate(lines):
            text = self.small_font.render(line, True, WHITE)
            self.screen.blit(text, (50, 200 + i * 30))
        
        # Draw input box
        input_box = pygame.Rect(50, 500, SCREEN_WIDTH - 100, 40)
        pygame.draw.rect(self.screen, WHITE, input_box, 2)
        
        input_text = self.small_font.render(self.input_text, True, WHITE)
        self.screen.blit(input_text, (60, 510))
        
        # Draw prompt
        prompt = self.small_font.render("Press ENTER to send, ESC to cancel", True, GRAY)
        self.screen.blit(prompt, (50, 550))
    
    def render_inventory(self):
        """Render inventory screen"""
        title = self.font.render("Inventory", True, WHITE)
        self.screen.blit(title, (50, 50))
        
        for i, item in enumerate(self.player.inventory):
            item_text = self.small_font.render(f"{item['name']} - {item.get('description', '')}", True, WHITE)
            self.screen.blit(item_text, (50, 100 + i * 30))
    
    def render_ui(self):
        """Render UI elements"""
        if self.player:
            # Player stats
            stats = [
                f"HP: {self.player.health}/{self.player.max_health}",
                f"Level: {self.player.level}",
                f"EXP: {self.player.experience}/{self.player.level * 100}",
                f"Depth: {self.player.depth}",
                f"Region: ({self.player.region_x}, {self.player.region_y})"
            ]
            
            for i, stat in enumerate(stats):
                text = self.small_font.render(stat, True, WHITE)
                self.screen.blit(text, (10, 10 + i * 25))
            
            # Game log
            for i, message in enumerate(self.game_log[-5:]):
                log_text = self.small_font.render(message, True, GRAY)
                self.screen.blit(log_text, (10, SCREEN_HEIGHT - 150 + i * 25))
        
        # State instructions
        instructions = self.get_state_instructions()
        if instructions:
            instr_text = self.small_font.render(instructions, True, WHITE)
            self.screen.blit(instr_text, (SCREEN_WIDTH - instr_text.get_width() - 10, SCREEN_HEIGHT - 30))
    
    def get_state_instructions(self):
        """Get instructions for current game state"""
        if self.state == GameState.MAIN_MENU:
            return "ENTER: Start Game | ESC: Quit"
        elif self.state == GameState.PLAYING:
            return "WASD: Move | C: Chat | I: Inventory | TAB: Generate Content"
        elif self.state == GameState.COMBAT:
            return "SPACE: Attack | R: Run"
        elif self.state == GameState.DIALOGUE:
            return "ENTER: Send | ESC: Cancel"
        elif self.state == GameState.INVENTORY:
            return "I/ESC: Close Inventory"
        return ""
    
    def wrap_text(self, text, font, max_width):
        """Wrap text to fit within max width"""
        words = text.split(' ')
        lines = []
        current_line = []
        
        for word in words:
            test_line = ' '.join(current_line + [word])
            test_width = font.size(test_line)[0]
            
            if test_width <= max_width:
                current_line.append(word)
            else:
                lines.append(' '.join(current_line))
                current_line = [word]
                
        if current_line:
            lines.append(' '.join(current_line))
            
        return lines
    
    def run(self):
        """Main game loop"""
        running = True
        while running:
            running = self.handle_events()
            self.render()
            self.clock.tick(FPS)
        
        pygame.quit()
        self.conn.close()

if __name__ == "__main__":
    game = Game()
    game.run()