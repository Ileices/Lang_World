"""
Code Generator - Safe execution of AI-generated code
"""

import ast
import sys
import io
import contextlib
from typing import Dict, Any, Optional
import traceback
from pathlib import Path


class CodeGenerator:
    """
    Safely executes AI-generated code in sandboxed environment
    """
    
    def __init__(self):
        self.sandbox = CodeSandbox()
        self.execution_history = []
        
        print("⚙️ Code Generator initialized")
    
    def safe_execute(self, code: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Safely execute AI-generated code
        
        Args:
            code: Python code to execute
            context: Context information about the code
            
        Returns:
            Execution result dictionary
        """
        try:
            if not code or not code.strip():
                return {'status': 'error', 'error': 'No code provided'}
            
            # Test in sandbox
            sandbox_result = self.sandbox.test_execution(code)
            
            if not sandbox_result['success']:
                return self._handle_execution_error(sandbox_result['error'], code, context)
            
            # If successful, code is validated but we don't execute it in live game
            # (to prevent unintended side effects)
            # Instead, we log it and can manually review/apply
            self._log_generated_code(code, context, sandbox_result)
            
            return {
                'status': 'success',
                'message': 'Code validated and logged',
                'output': sandbox_result.get('output', '')
            }
            
        except Exception as e:
            return self._handle_critical_error(e, code, context)
    
    def _handle_execution_error(self, error: str, code: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle code execution error"""
        print(f"⚠️ Code execution error: {error}")
        
        return {
            'status': 'error',
            'error': error,
            'message': 'Code execution failed in sandbox'
        }
    
    def _handle_critical_error(self, error: Exception, code: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle critical error in code generation"""
        print(f"❌ Critical code generation error: {str(error)}")
        traceback.print_exc()
        
        return {
            'status': 'critical_error',
            'error': str(error),
            'message': 'Code generation system error'
        }
    
    def _log_generated_code(self, code: str, context: Dict[str, Any], result: Dict[str, Any]):
        """Log AI-generated code for review"""
        try:
            log_dir = Path("game_world/code_templates/generated")
            log_dir.mkdir(parents=True, exist_ok=True)
            
            import time
            timestamp = int(time.time())
            log_file = log_dir / f"generated_{timestamp}.py"
            
            with open(log_file, 'w') as f:
                f.write(f"# AI-Generated Code\n")
                f.write(f"# Context: {context.get('type', 'unknown')}\n")
                f.write(f"# Status: {result['status']}\n")
                f.write(f"# Timestamp: {timestamp}\n\n")
                f.write(code)
            
            print(f"📝 Generated code logged: {log_file.name}")
            
        except Exception as e:
            print(f"❌ Error logging code: {str(e)}")


class CodeSandbox:
    """
    Sandboxed environment for testing code execution
    """
    
    def __init__(self):
        self.max_execution_time = 5  # seconds
        self.restricted_builtins = {
            'abs', 'all', 'any', 'ascii', 'bin', 'bool', 'bytes',
            'chr', 'dict', 'dir', 'divmod', 'enumerate', 'filter',
            'float', 'format', 'frozenset', 'hex', 'int', 'isinstance',
            'issubclass', 'iter', 'len', 'list', 'map', 'max', 'min',
            'next', 'oct', 'ord', 'pow', 'print', 'range', 'repr',
            'reversed', 'round', 'set', 'slice', 'sorted', 'str',
            'sum', 'tuple', 'type', 'zip'
        }
    
    def test_execution(self, code: str) -> Dict[str, Any]:
        """
        Test code execution in sandboxed environment
        
        Returns:
            Dictionary with success status, output, and any errors
        """
        try:
            # Redirect stdout to capture print statements
            output_buffer = io.StringIO()
            
            # Create restricted global namespace
            restricted_globals = {
                '__builtins__': {name: __builtins__[name] for name in self.restricted_builtins if name in __builtins__}
            }
            
            # Add safe imports
            import math
            import random
            restricted_globals['math'] = math
            restricted_globals['random'] = random
            
            with contextlib.redirect_stdout(output_buffer):
                # Execute code
                exec(code, restricted_globals)
            
            return {
                'success': True,
                'output': output_buffer.getvalue(),
                'error': None
            }
            
        except Exception as e:
            return {
                'success': False,
                'output': '',
                'error': f"{type(e).__name__}: {str(e)}"
            }
