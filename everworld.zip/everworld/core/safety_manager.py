"""
Safety Manager - Multi-layered safety validation for AI-generated content
"""

import ast
import re
import json
from typing import Dict, List, Any, Optional
from pathlib import Path
import hashlib


class SafetyManager:
    """
    Ensures all AI-generated content is safe to execute
    """
    
    def __init__(self):
        self.content_filters = ContentFilterSuite()
        self.code_validators = CodeValidatorSuite()
        self.safety_log_path = Path("game_world/safety/safety_log.json")
        self.safety_log_path.parent.mkdir(parents=True, exist_ok=True)
        
        print("🛡️ Safety Manager initialized")
    
    def validate_directive(self, directive: Dict[str, Any]) -> bool:
        """
        Validate an AI directive for safety
        
        Returns:
            True if safe, False if should be blocked
        """
        directive_type = directive.get('type', '')
        
        # Content safety check
        if not self.content_filters.validate(directive):
            self._log_safety_block(directive, "content_filter")
            return False
        
        # Code safety validation
        if directive_type == 'code_generation':
            code = directive.get('code', '')
            if not self.code_validators.validate(code):
                self._log_safety_block(directive, "code_validator")
                return False
        
        # Performance impact check
        if not self._check_performance_impact(directive):
            self._log_safety_block(directive, "performance")
            return False
        
        return True
    
    def _check_performance_impact(self, directive: Dict[str, Any]) -> bool:
        """Check if directive would have acceptable performance impact"""
        # For now, simple heuristics
        directive_type = directive.get('type', '')
        
        # Limit massive entity spawns
        if directive_type == 'entity_creation':
            # Single entity creation is fine
            return True
        
        if directive_type == 'world_modification':
            changes = directive.get('changes', {})
            # Limit to reasonable number of changes
            if len(changes) > 50:
                print("⚠️ Directive blocked: too many simultaneous world modifications")
                return False
        
        return True
    
    def _log_safety_block(self, directive: Dict[str, Any], reason: str):
        """Log a blocked directive"""
        try:
            log_entry = {
                'timestamp': str(datetime.now()),
                'reason': reason,
                'directive_type': directive.get('type', 'unknown'),
                'directive_hash': hashlib.md5(json.dumps(directive).encode()).hexdigest()
            }
            
            # Load existing log
            log = []
            if self.safety_log_path.exists():
                with open(self.safety_log_path, 'r') as f:
                    log = json.load(f)
            
            log.append(log_entry)
            
            # Keep last 1000 entries
            if len(log) > 1000:
                log = log[-1000:]
            
            with open(self.safety_log_path, 'w') as f:
                json.dump(log, f, indent=2)
                
        except Exception as e:
            print(f"❌ Error logging safety block: {str(e)}")


class ContentFilterSuite:
    """Filters for inappropriate or harmful content"""
    
    def __init__(self):
        # Blocked patterns (simple content filter)
        self.blocked_patterns = [
            r'import\s+os',
            r'import\s+subprocess',
            r'import\s+sys',
            r'__import__',
            r'exec\(',
            r'eval\(',
            r'compile\(',
            r'open\(',  # Restrict file operations
            r'delete',
            r'remove',
            r'unlink',
        ]
    
    def validate(self, directive: Dict[str, Any]) -> bool:
        """Validate content is appropriate"""
        # Convert directive to string for pattern matching
        content_str = json.dumps(directive).lower()
        
        # Check for blocked patterns
        for pattern in self.blocked_patterns:
            if re.search(pattern, content_str, re.IGNORECASE):
                print(f"⚠️ Content blocked: matches pattern '{pattern}'")
                return False
        
        return True


class CodeValidatorSuite:
    """Validates AI-generated code for safety"""
    
    def __init__(self):
        # Allowed imports for game code
        self.allowed_imports = {
            'pygame', 'math', 'random', 'json', 'time',
            'dataclasses', 'typing', 'enum', 'collections'
        }
        
        # Dangerous AST node types
        self.dangerous_nodes = {
            ast.Import, ast.ImportFrom  # We'll validate imports separately
        }
    
    def validate(self, code: str) -> bool:
        """
        Validate Python code for safety
        
        Returns:
            True if code is safe, False otherwise
        """
        if not code or not code.strip():
            return False
        
        try:
            # Parse code into AST
            tree = ast.parse(code)
            
            # Check for dangerous operations
            for node in ast.walk(tree):
                # Check imports
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    if not self._validate_import(node):
                        return False
                
                # Block eval/exec
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        if node.func.id in ['eval', 'exec', 'compile', '__import__']:
                            print(f"⚠️ Code blocked: dangerous function '{node.func.id}'")
                            return False
                
                # Block file operations
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        if node.func.id in ['open', 'file']:
                            print("⚠️ Code blocked: file operations not allowed")
                            return False
            
            return True
            
        except SyntaxError as e:
            print(f"⚠️ Code blocked: syntax error - {str(e)}")
            return False
        except Exception as e:
            print(f"⚠️ Code validation error: {str(e)}")
            return False
    
    def _validate_import(self, node) -> bool:
        """Validate import statement"""
        if isinstance(node, ast.Import):
            for alias in node.names:
                module = alias.name.split('.')[0]
                if module not in self.allowed_imports:
                    print(f"⚠️ Code blocked: import '{module}' not allowed")
                    return False
        
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                module = node.module.split('.')[0]
                if module not in self.allowed_imports:
                    print(f"⚠️ Code blocked: import from '{module}' not allowed")
                    return False
        
        return True


from datetime import datetime
