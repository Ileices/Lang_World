"""
AI Game Master - Core AI Integration System
Handles real-time AI generation, code execution, and game world modification
"""

import json
import requests
import time
import threading
from pathlib import Path
from typing import Dict, List, Any, Optional
import traceback


class AIGameMaster:
    """
    AETHERIUS - The Omniversal Architect
    An AI Game Master that generates, modifies, and orchestrates the entire game universe
    """
    
    def __init__(self, base_url="http://localhost:11434", model="llama2"):
        self.base_url = base_url
        self.model = model
        self.conversation_history = []
        self.generation_count = 0
        self.total_tokens = 0
        
        # Initialize sub-systems
        from .context_manager import ContextManager
        from .code_generator import CodeGenerator
        from .safety_manager import SafetyManager
        
        self.context_manager = ContextManager()
        self.code_generator = CodeGenerator()
        self.safety_manager = SafetyManager()
        
        # AI personality and voice
        self.personality = {
            'name': 'AETHERIUS',
            'role': 'Omniversal Architect',
            'tone': 'mysterious_wise',
            'creativity': 0.8,
            'verbosity': 0.7
        }
        
        print(f"🌌 AETHERIUS awakened - AI Game Master initialized")
    
    def get_game_context(self) -> Dict[str, Any]:
        """Provides comprehensive game state to AI"""
        return self.context_manager.build_context_prompt()
    
    def generate_dynamic_response(self, player_input: str, context_type: str = "dialogue",
                                 max_tokens: int = 2000) -> str:
        """
        AI generates responses with full game context
        
        Args:
            player_input: What the player said/did
            context_type: Type of interaction (dialogue, action, exploration, combat)
            max_tokens: Maximum response length
            
        Returns:
            AI-generated response with potential game directives
        """
        try:
            # Build comprehensive prompt with full game context
            full_prompt = self.context_manager.build_comprehensive_prompt(
                player_input, context_type
            )
            
            # Add to conversation history
            self.conversation_history.append({
                'role': 'user',
                'content': player_input,
                'context_type': context_type,
                'timestamp': time.time()
            })
            
            # Call Ollama API
            response = self._call_ollama(full_prompt, max_tokens)
            
            # Store response
            self.conversation_history.append({
                'role': 'assistant',
                'content': response,
                'timestamp': time.time()
            })
            
            # Process any AI directives embedded in response
            self._process_ai_directives(response)
            
            self.generation_count += 1
            
            return response
            
        except Exception as e:
            error_msg = f"Error in AI generation: {str(e)}"
            print(f"❌ {error_msg}")
            traceback.print_exc()
            return self._generate_fallback_response(player_input, context_type)
    
    def _call_ollama(self, prompt: str, max_tokens: int = 2000) -> str:
        """Call Ollama API with prompt"""
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "num_predict": max_tokens,
                        "temperature": self.personality['creativity'],
                        "top_p": 0.9
                    }
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                response_text = result.get("response", "").strip()
                
                # Track token usage if available
                if 'eval_count' in result:
                    self.total_tokens += result['eval_count']
                
                return response_text
            else:
                raise Exception(f"Ollama API returned status {response.status_code}")
                
        except requests.exceptions.Timeout:
            raise Exception("Ollama request timed out - is Ollama running?")
        except requests.exceptions.ConnectionError:
            raise Exception("Cannot connect to Ollama - is it running on localhost:11434?")
        except Exception as e:
            raise Exception(f"Ollama API error: {str(e)}")
    
    def _process_ai_directives(self, response: str):
        """
        Extract and execute AI-generated game modifications safely
        
        Looks for JSON blocks containing game directives:
        - code_generation: Execute new game code
        - world_modification: Change game world state
        - narrative_advancement: Progress storyline
        - entity_creation: Spawn new entities
        - mechanic_introduction: Add new game mechanics
        """
        try:
            directives = self._extract_directives(response)
            
            for directive in directives:
                # Safety check
                if not self.safety_manager.validate_directive(directive):
                    print(f"⚠️ AI directive blocked by safety system: {directive.get('type')}")
                    continue
                
                directive_type = directive.get('type')
                
                if directive_type == 'code_generation':
                    self.code_generator.safe_execute(directive.get('code', ''), directive)
                    
                elif directive_type == 'world_modification':
                    self.context_manager.apply_world_changes(directive.get('changes', {}))
                    
                elif directive_type == 'narrative_advancement':
                    self._advance_storyline(directive.get('narrative', {}))
                    
                elif directive_type == 'entity_creation':
                    self._create_entity(directive.get('entity', {}))
                    
                elif directive_type == 'mechanic_introduction':
                    self._introduce_mechanic(directive.get('mechanic', {}))
                    
                else:
                    print(f"⚠️ Unknown directive type: {directive_type}")
                    
        except Exception as e:
            print(f"❌ Error processing AI directives: {str(e)}")
            traceback.print_exc()
    
    def _extract_directives(self, response: str) -> List[Dict[str, Any]]:
        """Extract JSON directives from AI response"""
        directives = []
        lines = response.split('\n')
        
        in_json_block = False
        json_buffer = []
        
        for line in lines:
            stripped = line.strip()
            
            # Check for JSON block markers
            if stripped.startswith('```json'):
                in_json_block = True
                json_buffer = []
                continue
            elif stripped == '```' and in_json_block:
                in_json_block = False
                # Try to parse accumulated JSON
                json_text = '\n'.join(json_buffer)
                try:
                    directive = json.loads(json_text)
                    directives.append(directive)
                except json.JSONDecodeError:
                    pass
                continue
            
            if in_json_block:
                json_buffer.append(line)
            elif stripped.startswith('{') and stripped.endswith('}'):
                # Single-line JSON
                try:
                    directive = json.loads(stripped)
                    directives.append(directive)
                except json.JSONDecodeError:
                    pass
        
        return directives
    
    def _advance_storyline(self, narrative: Dict[str, Any]):
        """Process narrative advancement directive"""
        try:
            narrative_threads = self.context_manager.get_narrative_threads()
            
            # Add new narrative thread
            if 'new_thread' in narrative:
                narrative_threads.append(narrative['new_thread'])
            
            # Advance existing thread
            if 'advance_thread' in narrative:
                thread_id = narrative['advance_thread']['id']
                for thread in narrative_threads:
                    if thread.get('id') == thread_id:
                        thread['progress'] = narrative['advance_thread'].get('progress', 0)
                        thread['current_state'] = narrative['advance_thread'].get('state', '')
            
            self.context_manager.save_narrative_threads(narrative_threads)
            print(f"📖 Narrative advanced: {narrative.get('description', 'storyline progression')}")
            
        except Exception as e:
            print(f"❌ Error advancing storyline: {str(e)}")
    
    def _create_entity(self, entity: Dict[str, Any]):
        """Create a new game entity from AI directive"""
        try:
            # Validate entity has required fields
            required_fields = ['type', 'name']
            if not all(field in entity for field in required_fields):
                print(f"⚠️ Entity creation missing required fields: {required_fields}")
                return
            
            # Add entity to current region
            current_region = self.context_manager.get_current_region()
            if current_region:
                if 'entities' not in current_region:
                    current_region['entities'] = []
                current_region['entities'].append(entity)
                self.context_manager.save_current_region(current_region)
                print(f"✨ Created entity: {entity['name']} ({entity['type']})")
            
        except Exception as e:
            print(f"❌ Error creating entity: {str(e)}")
    
    def _introduce_mechanic(self, mechanic: Dict[str, Any]):
        """Introduce a new game mechanic"""
        try:
            mechanics_path = Path("game_world/code_templates/mechanics")
            mechanic_name = mechanic.get('name', 'unnamed_mechanic')
            
            # Save mechanic definition
            mechanic_file = mechanics_path / f"{mechanic_name}.json"
            with open(mechanic_file, 'w') as f:
                json.dump(mechanic, f, indent=2)
            
            print(f"🎮 New mechanic introduced: {mechanic_name}")
            
        except Exception as e:
            print(f"❌ Error introducing mechanic: {str(e)}")
    
    def _generate_fallback_response(self, player_input: str, context_type: str) -> str:
        """Generate fallback response when AI fails"""
        fallbacks = {
            'dialogue': "The cosmic energies swirl mysteriously... (AETHERIUS connection unstable)",
            'action': "Your action resonates through the void, awaiting manifestation...",
            'exploration': "The path ahead shimmers with uncertainty...",
            'combat': "Time seems to slow as reality reassembles itself..."
        }
        return fallbacks.get(context_type, "The Omniverse shifts unexpectedly...")
    
    def generate_origin_story(self, player_name: str) -> str:
        """Generate personalized origin story for player"""
        prompt = f"""
        You are AETHERIUS, the Omniversal Architect. Create an epic, personalized origin story 
        for a player named "{player_name}" who is about to enter the infinite Omniverse.
        
        The origin should:
        - Be dramatic and mysterious
        - Hint at their unique cosmic significance
        - Set up potential questlines
        - Be 3-4 sentences
        - End with them standing at the "Nexus of Realities"
        
        Speak directly to {player_name} in second person.
        """
        
        return self.generate_dynamic_response(prompt, "origin_story", max_tokens=500)
    
    def generate_region_enhancement(self, base_region: Dict[str, Any]) -> Dict[str, Any]:
        """Let AI enhance a generated region with unique characteristics"""
        prompt = f"""
        Enhance this game region with unique, creative characteristics:
        
        Base Region Data:
        {json.dumps(base_region, indent=2)}
        
        Add the following as JSON:
        - "environmental_hazards": [] (2-3 unique hazards)
        - "npc_factions": [] (1-2 factions with names and alignments)
        - "hidden_lore": [] (1-2 lore fragments)
        - "dynamic_weather": {{}} (weather system description)
        - "interactive_elements": [] (2-3 things player can interact with)
        - "atmosphere_description": "" (vivid sensory description)
        
        Return ONLY a JSON object with these fields.
        """
        
        response = self.generate_dynamic_response(prompt, "region_generation", max_tokens=1000)
        
        # Try to extract JSON from response
        directives = self._extract_directives(response)
        if directives:
            return directives[0]
        
        # Fallback to basic enhancement
        return {
            'environmental_hazards': ['unstable terrain'],
            'npc_factions': [],
            'hidden_lore': [],
            'atmosphere_description': 'A mysterious region awaiting discovery'
        }
    
    def generate_combat_decision(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate intelligent enemy combat decision"""
        prompt = f"""
        You are controlling an enemy in combat. Analyze the situation and decide the enemy's action.
        
        Combat Context:
        {json.dumps(context, indent=2)}
        
        Generate a strategic combat action as JSON:
        {{
          "action_type": "attack/defend/special_ability/retreat",
          "target": "player",
          "ability_name": "name of ability used",
          "tactical_reasoning": "why this action makes sense",
          "flavor_text": "dramatic description of the action"
        }}
        
        Return ONLY the JSON object.
        """
        
        response = self.generate_dynamic_response(prompt, "combat_decision", max_tokens=500)
        
        directives = self._extract_directives(response)
        if directives:
            return directives[0]
        
        # Fallback to basic attack
        return {
            'action_type': 'attack',
            'target': 'player',
            'ability_name': 'basic_attack',
            'tactical_reasoning': 'aggressive offense',
            'flavor_text': 'The enemy strikes!'
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get AI usage statistics"""
        return {
            'generations': self.generation_count,
            'total_tokens': self.total_tokens,
            'conversation_length': len(self.conversation_history),
            'model': self.model,
            'personality': self.personality['name']
        }
