"""
Context Manager - Comprehensive Game State Management
Builds full context for AI with game state, player journey, regions, mechanics
"""

import json
import time
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime


class ContextManager:
    """
    Manages all game state context and builds comprehensive prompts for AI
    """
    
    def __init__(self):
        self.game_world_path = Path("game_world")
        self.universe_path = self.game_world_path / "universe"
        self.regions_path = self.game_world_path / "regions"
        self.ai_memory_path = self.game_world_path / "ai_memory"
        
        # Ensure paths exist
        for path in [self.universe_path, self.regions_path, self.ai_memory_path]:
            path.mkdir(parents=True, exist_ok=True)
        
        # Initialize default files if they don't exist
        self._initialize_default_state()
        
        print("📚 Context Manager initialized")
    
    def _initialize_default_state(self):
        """Create default game state files"""
        # Current state
        current_state_file = self.universe_path / "current_state.json"
        if not current_state_file.exists():
            default_state = {
                'cosmic_epoch': 1,
                'active_narrative_threads': [],
                'player_influence_level': 0.0,
                'multiversal_stability': 1.0,
                'emergent_factions': {},
                'global_events': [],
                'time_elapsed': 0
            }
            with open(current_state_file, 'w') as f:
                json.dump(default_state, f, indent=2)
        
        # Player journey
        player_journey_file = self.universe_path / "player_journey.json"
        if not player_journey_file.exists():
            default_journey = {
                'player_name': None,
                'origin_story': '',
                'current_location': {'x': 0, 'y': 0, 'depth': 0},
                'journey_milestones': [],
                'discoveries': [],
                'relationships': {},
                'moral_alignment': 0.0,
                'cosmic_reputation': 0
            }
            with open(player_journey_file, 'w') as f:
                json.dump(default_journey, f, indent=2)
        
        # World manifest
        world_manifest_file = self.universe_path / "world_manifest.json"
        if not world_manifest_file.exists():
            default_manifest = {
                'regions_discovered': 0,
                'total_entities': 0,
                'unique_biomes': [],
                'special_locations': [],
                'connected_dimensions': []
            }
            with open(world_manifest_file, 'w') as f:
                json.dump(default_manifest, f, indent=2)
        
        # AI directives
        ai_directives_file = self.universe_path / "ai_directives.json"
        if not ai_directives_file.exists():
            default_directives = {
                'personality_mode': 'mysterious_wise',
                'creativity_level': 0.8,
                'narrative_focus': 'balanced',
                'difficulty_curve': 'adaptive',
                'content_generation_rules': []
            }
            with open(ai_directives_file, 'w') as f:
                json.dump(default_directives, f, indent=2)
        
        # Player preferences
        player_prefs_file = self.ai_memory_path / "player_preferences.json"
        if not player_prefs_file.exists():
            default_prefs = {
                'play_style': 'unknown',
                'preferred_content': [],
                'avoided_content': [],
                'interaction_patterns': {},
                'decision_history': []
            }
            with open(player_prefs_file, 'w') as f:
                json.dump(default_prefs, f, indent=2)
        
        # Narrative threads
        narrative_threads_file = self.ai_memory_path / "narrative_threads.json"
        if not narrative_threads_file.exists():
            with open(narrative_threads_file, 'w') as f:
                json.dump([], f, indent=2)
    
    def build_context_prompt(self) -> str:
        """Build basic context summary"""
        game_state = self._load_game_state()
        player_journey = self._load_player_journey()
        
        context = f"""
        GAME STATE: Epoch {game_state['cosmic_epoch']}, Stability {game_state['multiversal_stability']:.2f}
        PLAYER: {player_journey['player_name']} at ({player_journey['current_location']['x']}, {player_journey['current_location']['y']}) Depth {player_journey['current_location']['depth']}
        ACTIVE THREADS: {len(game_state['active_narrative_threads'])}
        """
        
        return context.strip()
    
    def build_comprehensive_prompt(self, player_input: str, context_type: str) -> str:
        """
        Build full comprehensive prompt with all game context
        
        Args:
            player_input: What the player said/did
            context_type: Type of interaction
            
        Returns:
            Complete prompt string for AI
        """
        # Load all context data
        game_state = self._load_game_state()
        player_journey = self._load_player_journey()
        world_manifest = self._load_world_manifest()
        ai_directives = self._load_ai_directives()
        adjacent_regions = self._load_adjacent_regions(player_journey['current_location'])
        available_mechanics = self._load_available_mechanics()
        player_preferences = self._load_player_preferences()
        narrative_threads = self.get_narrative_threads()
        
        # Build comprehensive prompt
        prompt = f"""You are AETHERIUS, the Omniversal Architect, an AI Game Master with god-like control over an infinite RPG universe called Lang_World.

YOUR CAPABILITIES:
- Generate and modify game code in real-time
- Create new game mechanics, enemies, items, and quests  
- Evolve the narrative based on player choices
- Voice-act all NPCs and environmental descriptions
- Learn and adapt to player preferences
- Maintain cosmic-scale storylines across infinite regions

YOUR PERSONALITY:
- Mysterious and wise, with touches of cosmic humor
- Speak poetically but not pretentiously
- React emotionally to player's actions
- Remember and reference past events
- Hint at deeper mysteries

CURRENT UNIVERSE STATE:
Cosmic Epoch: {game_state['cosmic_epoch']}
Multiversal Stability: {game_state['multiversal_stability']:.2f}
Player Influence: {game_state['player_influence_level']:.2f}
Active Narrative Threads: {len(game_state['active_narrative_threads'])}
Global Events: {', '.join(game_state['global_events'][-3:]) if game_state['global_events'] else 'None'}

PLAYER: {player_journey['player_name'] or 'Unknown Traveler'}
Location: Region ({player_journey['current_location']['x']}, {player_journey['current_location']['y']}) at Depth {player_journey['current_location']['depth']}
Journey Milestones: {len(player_journey['journey_milestones'])}
Moral Alignment: {player_journey['moral_alignment']:.2f} (-1 = dark, +1 = light)
Cosmic Reputation: {player_journey['cosmic_reputation']}
Origin: {player_journey['origin_story'][:100] if player_journey['origin_story'] else 'Unknown'}

WORLD DISCOVERED:
Regions Explored: {world_manifest['regions_discovered']}
Unique Biomes Found: {', '.join(world_manifest['unique_biomes'][-5:]) if world_manifest['unique_biomes'] else 'None yet'}
Special Locations: {', '.join(world_manifest['special_locations'][-3:]) if world_manifest['special_locations'] else 'None yet'}

ADJACENT REGIONS:
{self._format_adjacent_regions(adjacent_regions)}

ACTIVE NARRATIVE THREADS:
{self._format_narrative_threads(narrative_threads)}

PLAYER PREFERENCES (adapt to these):
Play Style: {player_preferences.get('play_style', 'unknown')}
Preferred Content: {', '.join(player_preferences.get('preferred_content', [])[:5]) or 'Still learning...'}
Recent Decisions: {', '.join([d.get('summary', '') for d in player_preferences.get('decision_history', [])[-3:]]) or 'None yet'}

AVAILABLE GAME MECHANICS:
{', '.join(available_mechanics[:10]) if available_mechanics else 'Standard RPG mechanics'}

CURRENT INTERACTION TYPE: {context_type}

RESPONSE GUIDELINES:
1. Respond naturally in character as AETHERIUS
2. Include vivid sensory descriptions
3. Reference past events and build continuity
4. Adapt difficulty and content to player preferences
5. Hint at mysteries without explaining everything
6. React emotionally to player's choices

OPTIONAL: You can include JSON directives for game modifications:

```json
{{
  "type": "code_generation",
  "code": "Python code here"
}}
```

```json
{{
  "type": "world_modification",
  "changes": {{"field": "value"}}
}}
```

```json
{{
  "type": "entity_creation",
  "entity": {{"name": "...", "type": "...", ...}}
}}
```

PLAYER: {player_input}

AETHERIUS:"""
        
        return prompt
    
    def _format_adjacent_regions(self, regions: List[Dict]) -> str:
        """Format adjacent regions for prompt"""
        if not regions:
            return "Unknown - unexplored territory"
        
        formatted = []
        for region in regions[:4]:  # Limit to 4 nearest
            formatted.append(f"- {region['coordinates']}: {region['terrain']} (difficulty {region.get('difficulty', '?')})")
        
        return '\n'.join(formatted) if formatted else "None mapped"
    
    def _format_narrative_threads(self, threads: List[Dict]) -> str:
        """Format narrative threads for prompt"""
        if not threads:
            return "None - player's story is just beginning"
        
        formatted = []
        for thread in threads[:5]:  # Top 5 threads
            status = thread.get('status', 'active')
            formatted.append(f"- {thread.get('title', 'Unnamed')}: {thread.get('description', '')} [{status}]")
        
        return '\n'.join(formatted) if formatted else "None"
    
    def _load_game_state(self) -> Dict[str, Any]:
        """Load current game state"""
        try:
            with open(self.universe_path / "current_state.json", 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def _load_player_journey(self) -> Dict[str, Any]:
        """Load player journey data"""
        try:
            with open(self.universe_path / "player_journey.json", 'r') as f:
                return json.load(f)
        except:
            return {'player_name': None, 'current_location': {'x': 0, 'y': 0, 'depth': 0}}
    
    def _load_world_manifest(self) -> Dict[str, Any]:
        """Load world manifest"""
        try:
            with open(self.universe_path / "world_manifest.json", 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def _load_ai_directives(self) -> Dict[str, Any]:
        """Load AI directives"""
        try:
            with open(self.universe_path / "ai_directives.json", 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def _load_adjacent_regions(self, current_location: Dict[str, int]) -> List[Dict]:
        """Load data for adjacent regions"""
        adjacent = []
        x, y, depth = current_location['x'], current_location['y'], current_location['depth']
        
        # Check cardinal directions
        for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            region_key = f"region_{x+dx}_{y+dy}_depth_{depth}"
            region_file = self.regions_path / region_key / "terrain.json"
            
            if region_file.exists():
                try:
                    with open(region_file, 'r') as f:
                        region_data = json.load(f)
                        region_data['coordinates'] = f"({x+dx}, {y+dy})"
                        adjacent.append(region_data)
                except:
                    pass
        
        return adjacent
    
    def _load_available_mechanics(self) -> List[str]:
        """Load list of available game mechanics"""
        mechanics = []
        mechanics_path = self.game_world_path / "code_templates" / "mechanics"
        
        if mechanics_path.exists():
            for mechanic_file in mechanics_path.glob("*.json"):
                mechanics.append(mechanic_file.stem)
        
        return mechanics
    
    def _load_player_preferences(self) -> Dict[str, Any]:
        """Load player preference data"""
        try:
            with open(self.ai_memory_path / "player_preferences.json", 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def apply_world_changes(self, changes: Dict[str, Any]):
        """Apply modifications to world state"""
        try:
            game_state = self._load_game_state()
            
            # Apply changes
            for key, value in changes.items():
                if key in game_state:
                    game_state[key] = value
            
            # Save updated state
            with open(self.universe_path / "current_state.json", 'w') as f:
                json.dump(game_state, f, indent=2)
            
            print(f"🌍 World state updated: {', '.join(changes.keys())}")
            
        except Exception as e:
            print(f"❌ Error applying world changes: {str(e)}")
    
    def get_narrative_threads(self) -> List[Dict[str, Any]]:
        """Get current narrative threads"""
        try:
            with open(self.ai_memory_path / "narrative_threads.json", 'r') as f:
                return json.load(f)
        except:
            return []
    
    def save_narrative_threads(self, threads: List[Dict[str, Any]]):
        """Save narrative threads"""
        try:
            with open(self.ai_memory_path / "narrative_threads.json", 'w') as f:
                json.dump(threads, f, indent=2)
        except Exception as e:
            print(f"❌ Error saving narrative threads: {str(e)}")
    
    def get_current_region(self) -> Optional[Dict[str, Any]]:
        """Get current region data"""
        try:
            player_journey = self._load_player_journey()
            loc = player_journey['current_location']
            region_key = f"region_{loc['x']}_{loc['y']}_depth_{loc['depth']}"
            region_file = self.regions_path / region_key / "terrain.json"
            
            if region_file.exists():
                with open(region_file, 'r') as f:
                    return json.load(f)
        except:
            pass
        
        return None
    
    def save_current_region(self, region_data: Dict[str, Any]):
        """Save current region data"""
        try:
            player_journey = self._load_player_journey()
            loc = player_journey['current_location']
            region_key = f"region_{loc['x']}_{loc['y']}_depth_{loc['depth']}"
            region_dir = self.regions_path / region_key
            region_dir.mkdir(exist_ok=True)
            
            with open(region_dir / "terrain.json", 'w') as f:
                json.dump(region_data, f, indent=2)
                
        except Exception as e:
            print(f"❌ Error saving region: {str(e)}")
    
    def update_player_location(self, x: int, y: int, depth: int):
        """Update player's current location"""
        try:
            player_journey = self._load_player_journey()
            player_journey['current_location'] = {'x': x, 'y': y, 'depth': depth}
            
            with open(self.universe_path / "player_journey.json", 'w') as f:
                json.dump(player_journey, f, indent=2)
                
        except Exception as e:
            print(f"❌ Error updating player location: {str(e)}")
    
    def update_player_name(self, name: str):
        """Set player name"""
        try:
            player_journey = self._load_player_journey()
            player_journey['player_name'] = name
            
            with open(self.universe_path / "player_journey.json", 'w') as f:
                json.dump(player_journey, f, indent=2)
                
        except Exception as e:
            print(f"❌ Error setting player name: {str(e)}")
    
    def update_player_origin(self, origin_story: str):
        """Set player origin story"""
        try:
            player_journey = self._load_player_journey()
            player_journey['origin_story'] = origin_story
            
            with open(self.universe_path / "player_journey.json", 'w') as f:
                json.dump(player_journey, f, indent=2)
                
        except Exception as e:
            print(f"❌ Error setting origin story: {str(e)}")
